ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS selected boolean NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION public.check_team_selection(p_code text)
RETURNS TABLE (registration_code text, team_name text, college_name text, selected boolean)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT r.registration_code, r.team_name, r.college_name, r.selected
  FROM public.registrations r
  WHERE upper(trim(r.registration_code)) = upper(trim(p_code))
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.check_team_selection(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.check_team_selection(text) TO anon, authenticated;