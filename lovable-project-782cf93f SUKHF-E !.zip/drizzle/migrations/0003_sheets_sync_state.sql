CREATE TABLE public.integration_state (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.integration_state TO service_role;

ALTER TABLE public.integration_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "integration state admin read" ON public.integration_state
  FOR SELECT TO authenticated USING (public.is_admin());

ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS sheet_synced_at timestamptz,
  ADD COLUMN IF NOT EXISTS sheet_row_number integer;