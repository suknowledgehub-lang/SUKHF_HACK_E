ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS participation_type text;

ALTER TABLE public.registrations
  DROP CONSTRAINT IF EXISTS registrations_participation_type_check;

ALTER TABLE public.registrations
  ADD CONSTRAINT registrations_participation_type_check
  CHECK (participation_type IS NULL OR participation_type IN ('IDEATION','PROTOTYPE'));

CREATE OR REPLACE FUNCTION public.submit_registration(
  p_team_name text, p_team_lead_name text, p_team_lead_phone text, p_college_name text,
  p_track_id uuid, p_track_name text, p_member2_name text, p_member3_name text,
  p_ppt_file_name text, p_ppt_file_size bigint, p_ppt_path text,
  p_participation_type text DEFAULT NULL
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_code text;
  v_type text;
BEGIN
  v_type := upper(nullif(btrim(coalesce(p_participation_type, '')), ''));
  IF v_type IS NOT NULL AND v_type NOT IN ('IDEATION','PROTOTYPE') THEN
    RAISE EXCEPTION 'Invalid participation type';
  END IF;

  INSERT INTO public.registrations (
    registration_code, team_name, team_lead_name, team_lead_phone, college_name,
    track_id, track_name, member2_name, member3_name,
    ppt_file_name, ppt_file_size, ppt_path, ppt_uploaded_at, participation_type
  ) VALUES (
    '', p_team_name, p_team_lead_name, p_team_lead_phone, p_college_name,
    p_track_id, coalesce(p_track_name, ''), p_member2_name, p_member3_name,
    p_ppt_file_name, p_ppt_file_size, p_ppt_path, now(), v_type
  )
  RETURNING registration_code INTO v_code;

  RETURN v_code;
END;
$function$;

INSERT INTO public.site_content (key, value)
VALUES ('ideation_prototype', jsonb_build_object(
  'enabled', true,
  'heading', 'IDEATION OR PROTOTYPE',
  'subheading', 'Turn your idea into impact — or bring your prototype to life.',
  'ideation_title', 'IDEATION',
  'ideation_description', 'For participants who have an innovative idea and want to develop, validate, and present their concept.',
  'prototype_title', 'PROTOTYPE',
  'prototype_description', 'For participants who already have a concept or solution and want to build, demonstrate, and refine a working prototype.',
  'ideation_registration_enabled', true,
  'prototype_registration_enabled', true
))
ON CONFLICT (key) DO NOTHING;