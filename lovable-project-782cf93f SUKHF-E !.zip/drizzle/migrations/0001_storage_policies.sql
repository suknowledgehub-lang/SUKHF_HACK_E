-- PPT submissions: anyone may upload, only admins may read
create policy "ppt public upload" on storage.objects for insert to anon, authenticated
  with check (bucket_id = 'ppt-submissions');
create policy "ppt admin read" on storage.objects for select to authenticated
  using (bucket_id = 'ppt-submissions' and public.is_admin());
create policy "ppt admin delete" on storage.objects for delete to anon, authenticated
  using (bucket_id = 'ppt-submissions' and public.is_admin());

-- Sponsor logos and site assets: readable by everyone (via signed URLs), writable by admins
create policy "sponsor logos read" on storage.objects for select to anon, authenticated
  using (bucket_id in ('sponsor-logos','site-assets'));
create policy "sponsor logos admin write" on storage.objects for insert to authenticated
  with check (bucket_id in ('sponsor-logos','site-assets') and public.is_admin());
create policy "sponsor logos admin update" on storage.objects for update to authenticated
  using (bucket_id in ('sponsor-logos','site-assets') and public.is_admin());
create policy "sponsor logos admin delete" on storage.objects for delete to authenticated
  using (bucket_id in ('sponsor-logos','site-assets') and public.is_admin());