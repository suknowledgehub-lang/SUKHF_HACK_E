CREATE OR REPLACE FUNCTION public.submit_registration(
  p_team_name text,
  p_team_lead_name text,
  p_team_lead_phone text,
  p_college_name text,
  p_track_id uuid,
  p_track_name text,
  p_member2_name text,
  p_member3_name text,
  p_ppt_file_name text,
  p_ppt_file_size bigint,
  p_ppt_path text
) RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_code text;
BEGIN
  INSERT INTO public.registrations (
    registration_code, team_name, team_lead_name, team_lead_phone, college_name,
    track_id, track_name, member2_name, member3_name,
    ppt_file_name, ppt_file_size, ppt_path, ppt_uploaded_at
  ) VALUES (
    '', p_team_name, p_team_lead_name, p_team_lead_phone, p_college_name,
    p_track_id, coalesce(p_track_name, ''), p_member2_name, p_member3_name,
    p_ppt_file_name, p_ppt_file_size, p_ppt_path, now()
  )
  RETURNING registration_code INTO v_code;

  RETURN v_code;
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_registration(text,text,text,text,uuid,text,text,text,text,bigint,text) TO anon, authenticated;
