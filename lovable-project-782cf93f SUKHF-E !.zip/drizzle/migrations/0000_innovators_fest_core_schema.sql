-- ============ ROLES ============
create type public.app_role as enum ('admin','editor','user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(auth.uid(), 'admin')
$$;

create policy "own roles readable" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.is_admin());

create table public.admin_allowlist (
  email text primary key,
  created_at timestamptz not null default now()
);
grant all on public.admin_allowlist to service_role;
alter table public.admin_allowlist enable row level security;
insert into public.admin_allowlist (email) values ('k06265921@gmail.com');

-- ============ HELPERS ============
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ============ EVENT SETTINGS ============
create table public.event_settings (
  id uuid primary key default gen_random_uuid(),
  singleton boolean not null default true unique,
  event_name text not null default 'INNOVATORS FEST 2026',
  event_year text not null default '2026',
  tagline text not null default 'BUILD. PITCH. LAUNCH.',
  description text not null default 'A high-impact student hackathon bringing together builders, innovators, mentors and judges to transform ideas into startup-ready solutions.',
  organizer text not null default 'SULTAN ULOOM KNOWLEDGE HUB',
  venue text not null default 'Ghulam Ahmed Hall, Muffakham Jah College of Engineering & Technology',
  city text not null default 'HYDERABAD',
  address text not null default 'Banjara Hills, Hyderabad, Telangana',
  start_date timestamptz not null default '2026-10-13T09:00:00+05:30',
  end_date timestamptz not null default '2026-10-14T20:00:00+05:30',
  date_label text not null default '13-14 OCTOBER 2026',
  duration_label text not null default '35-HOUR HACKATHON',
  registration_open boolean not null default true,
  registration_button_text text not null default 'REGISTER YOUR TEAM',
  registration_close_date timestamptz,
  contact_email text not null default '',
  contact_phone text not null default '',
  social_links jsonb not null default '[]'::jsonb,
  loading_enabled boolean not null default true,
  loading_text text not null default 'LOADING',
  loading_logo_url text,
  organizer_logo_url text,
  updated_at timestamptz not null default now()
);
grant select on public.event_settings to anon;
grant select, insert, update on public.event_settings to authenticated;
grant all on public.event_settings to service_role;
alter table public.event_settings enable row level security;
create policy "event settings public read" on public.event_settings for select to anon, authenticated using (true);
create policy "event settings admin write" on public.event_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
create trigger t_event_settings_updated before update on public.event_settings for each row execute function public.touch_updated_at();
insert into public.event_settings (singleton) values (true);

-- ============ SITE CONTENT (key/value blocks) ============
create table public.site_content (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
grant select on public.site_content to anon;
grant select, insert, update, delete on public.site_content to authenticated;
grant all on public.site_content to service_role;
alter table public.site_content enable row level security;
create policy "site content public read" on public.site_content for select to anon, authenticated using (true);
create policy "site content admin write" on public.site_content for all to authenticated using (public.is_admin()) with check (public.is_admin());
create trigger t_site_content_updated before update on public.site_content for each row execute function public.touch_updated_at();

insert into public.site_content (key, value) values
('hero', '{"headline":"INNOVATORS FEST 2026","city":"HYDERABAD","dates":"13-14 OCTOBER 2026","duration":"35-HOUR HACKATHON","tagline":"BUILD. PITCH. LAUNCH.","description":"A high-impact student hackathon bringing together builders, innovators, mentors and judges to transform ideas into startup-ready solutions.","location":"Ghulam Ahmed Hall, Muffakham Jah College of Engineering & Technology, Banjara Hills, Hyderabad","primary_button":"REGISTER YOUR TEAM","secondary_button":"EXPLORE TRACKS"}'::jsonb),
('about', '{"heading":"ABOUT THE FEST","body":"Innovators Fest 2026 is a 35-hour hackathon and startup innovation event designed to bring together student builders, innovators and problem solvers.\n\nParticipants build their solutions during the hackathon and present their ideas before judges on the second day.\n\nThe event focuses on innovation, technology, entrepreneurship, real-world problem solving and startup potential.","stats":[{"label":"HOURS","value":"35"},{"label":"DAYS","value":"2"},{"label":"MEMBERS PER TEAM","value":"3"},{"label":"TRACKS","value":"7"}]}'::jsonb),
('format', '{"heading":"35-HOUR HACKATHON","day1_title":"DAY 1 - BUILD","day1_date":"13 OCTOBER 2026","day1_points":["Ideation","Problem Understanding","Development","Prototype Building","Mentorship","Testing","Iteration","Final Preparation"],"day2_title":"DAY 2 - PITCH","day2_date":"14 OCTOBER 2026","day2_points":["Final Pitch","Judging","Startup Evaluation","Results","Certificates","Top 3 Awards"],"note":"The Team Lead will present the final project in front of the judges."}'::jsonb),
('how_it_works', '{"heading":"HOW IT WORKS","steps":[{"title":"REGISTER YOUR TEAM","description":"Form a team of exactly 3 members - 1 Team Lead and 2 Team Members."},{"title":"SELECT A TRACK","description":"Choose the problem space that matches your idea."},{"title":"SUBMIT YOUR PPT","description":"Upload your project presentation during registration."},{"title":"BUILD ON DAY 1","description":"Ideate, develop and prototype with mentor support."},{"title":"PITCH ON DAY 2","description":"The Team Lead pitches the project before the judges."},{"title":"GET RECOGNIZED","description":"Certificates for participants, prizes for the Top 3 teams."}]}'::jsonb),
('judging', '{"heading":"JUDGING","subheading":"Day 2 is not only technical judging - projects are evaluated for startup potential.","note":"The Team Lead will pitch the project on Day 2."}'::jsonb),
('prizes', '{"heading":"PRIZES & STARTUP BENEFITS","subheading":"The Top 3 winning teams receive prizes and recognition.","funding":"Rs 1,00,000+ FUNDING ASSISTANCE","funding_note":"Funding assistance is subject to evaluation and is not a guaranteed cash prize per winner."}'::jsonb),
('certificates', '{"heading":"CERTIFICATES","subheading":"Certificates are distributed only on Day 2.","types":[{"title":"PARTICIPATION CERTIFICATE","description":"Awarded to all participants on Day 2."},{"title":"TOP 3 WINNER CERTIFICATES","description":"Awarded to the three winning teams on Day 2."}]}'::jsonb),
('winners', '{"heading":"WINNERS","subheading":"Celebrating the Top 3 teams of Innovators Fest."}'::jsonb),
('sponsors', '{"heading":"OUR SPONSORS","subheading":"POWERED BY INNOVATION"}'::jsonb),
('faq', '{"heading":"FREQUENTLY ASKED QUESTIONS","subheading":"Everything you need to know before you register."}'::jsonb),
('cta', '{"heading":"YOUR IDEA COULD BE THE NEXT BIG STARTUP.","subheading":"BUILD. PITCH. GET RECOGNIZED.","button":"REGISTER YOUR TEAM"}'::jsonb),
('footer', '{"note":"Organized by Sultan Uloom Knowledge Hub","address":"Ghulam Ahmed Hall, MJCET, Banjara Hills, Hyderabad"}'::jsonb),
('organizer', '{"heading":"ORGANIZED BY","name":"SULTAN ULOOM KNOWLEDGE HUB","description":"Organizing Innovators Fest 2026","venue":"Ghulam Ahmed Hall, Muffakham Jah College of Engineering & Technology, Banjara Hills, Hyderabad"}'::jsonb);

-- ============ TRACKS ============
create table public.tracks (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  icon text not null default 'sparkles',
  category_label text not null default 'TRACK',
  display_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.tracks to anon;
grant select, insert, update, delete on public.tracks to authenticated;
grant all on public.tracks to service_role;
alter table public.tracks enable row level security;
create policy "tracks public read" on public.tracks for select to anon, authenticated using (true);
create policy "tracks admin write" on public.tracks for all to authenticated using (public.is_admin()) with check (public.is_admin());
create trigger t_tracks_updated before update on public.tracks for each row execute function public.touch_updated_at();

insert into public.tracks (name, description, icon, category_label, display_order) values
('Generative & Agentic AI','Artificial intelligence, AI powered applications, intelligent agents, automation and machine learning.','brain','ARTIFICIAL INTELLIGENCE',1),
('Health Tech','Digital healthcare, wellness, medical technology and healthcare innovation.','heart-pulse','HEALTHCARE',2),
('Smart Cities','Urban technology, mobility, infrastructure, sustainability and connected cities.','building','URBAN TECH',3),
('Open Web Softwares','Open web platforms, developer tools, software products and internet-based innovation.','globe','WEB & SOFTWARE',4),
('Open Innovation','Bold ideas and solutions that do not fit into a single predefined category.','lightbulb','OPEN',5),
('Hardware / IoT','Connected devices, embedded systems, sensors, robotics and hardware innovation.','cpu','HARDWARE',6),
('Fintech','Financial technology, digital payments, financial inclusion and smarter financial systems.','wallet','FINANCE',7);

-- ============ SCHEDULE ============
create table public.schedule_items (
  id uuid primary key default gen_random_uuid(),
  day int not null default 1,
  day_label text not null default 'DAY 1',
  date_label text not null default '13 OCTOBER 2026',
  time_label text not null default '',
  title text not null,
  description text not null default '',
  display_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.schedule_items to anon;
grant select, insert, update, delete on public.schedule_items to authenticated;
grant all on public.schedule_items to service_role;
alter table public.schedule_items enable row level security;
create policy "schedule public read" on public.schedule_items for select to anon, authenticated using (true);
create policy "schedule admin write" on public.schedule_items for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.schedule_items (day, day_label, date_label, time_label, title, description, display_order) values
(1,'DAY 1','13 OCTOBER 2026','08:00 AM','Registration / Check-in','Team check-in and kit distribution at Ghulam Ahmed Hall.',1),
(1,'DAY 1','13 OCTOBER 2026','09:30 AM','Opening Ceremony','Welcome address by Sultan Uloom Knowledge Hub.',2),
(1,'DAY 1','13 OCTOBER 2026','10:15 AM','Track Briefing','Track-wise problem statements and expectations.',3),
(1,'DAY 1','13 OCTOBER 2026','11:00 AM','Hackathon Begins','The 35-hour clock starts.',4),
(1,'DAY 1','13 OCTOBER 2026','11:30 AM','Ideation','Refine the problem and lock the solution approach.',5),
(1,'DAY 1','13 OCTOBER 2026','01:00 PM','Development','Core build phase.',6),
(1,'DAY 1','13 OCTOBER 2026','04:00 PM','Mentor Sessions','One-on-one reviews with industry mentors.',7),
(1,'DAY 1','13 OCTOBER 2026','07:00 PM','Prototype Building','Turning the idea into a working prototype.',8),
(1,'DAY 1','13 OCTOBER 2026','11:00 PM','Testing','Debugging, testing and iteration.',9),
(1,'DAY 1','13 OCTOBER 2026','04:00 AM','Final Preparation','Polish the build and prepare the pitch.',10),
(2,'DAY 2','14 OCTOBER 2026','10:00 AM','Final Pitching','Team Leads pitch their projects before the judges.',11),
(2,'DAY 2','14 OCTOBER 2026','12:30 PM','Judging','Evaluation against the judging criteria.',12),
(2,'DAY 2','14 OCTOBER 2026','02:00 PM','Startup Evaluation','Market potential and scalability review.',13),
(2,'DAY 2','14 OCTOBER 2026','04:00 PM','Results','Announcement of evaluation outcomes.',14),
(2,'DAY 2','14 OCTOBER 2026','04:30 PM','Certificate Distribution','Participation certificates awarded.',15),
(2,'DAY 2','14 OCTOBER 2026','05:15 PM','Top 3 Winner Announcement','The three winning teams are revealed.',16),
(2,'DAY 2','14 OCTOBER 2026','05:45 PM','Prize Distribution','Prizes and winner certificates.',17),
(2,'DAY 2','14 OCTOBER 2026','06:30 PM','Closing','Closing address and networking.',18);

-- ============ JUDGING CRITERIA ============
create table public.judging_criteria (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  display_order int not null default 0,
  active boolean not null default true
);
grant select on public.judging_criteria to anon;
grant select, insert, update, delete on public.judging_criteria to authenticated;
grant all on public.judging_criteria to service_role;
alter table public.judging_criteria enable row level security;
create policy "judging public read" on public.judging_criteria for select to anon, authenticated using (true);
create policy "judging admin write" on public.judging_criteria for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.judging_criteria (title, description, display_order) values
('Innovation','Originality of the idea and the novelty of the approach.',1),
('Technical Implementation','Quality, depth and correctness of the technical build.',2),
('Impact','Real-world value created for users and communities.',3),
('Feasibility','How realistically the solution can be delivered.',4),
('Scalability','Ability to grow beyond the prototype.',5),
('Startup Potential','Market opportunity and viability as a venture.',6),
('Presentation','Clarity and conviction of the Team Lead pitch.',7);

-- ============ PRIZES ============
create table public.prizes (
  id uuid primary key default gen_random_uuid(),
  position_label text not null,
  title text not null default '',
  description text not null default '',
  amount_label text not null default '',
  display_order int not null default 0,
  active boolean not null default true
);
grant select on public.prizes to anon;
grant select, insert, update, delete on public.prizes to authenticated;
grant all on public.prizes to service_role;
alter table public.prizes enable row level security;
create policy "prizes public read" on public.prizes for select to anon, authenticated using (true);
create policy "prizes admin write" on public.prizes for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.prizes (position_label, title, description, amount_label, display_order) values
('01','FIRST PLACE','Winner trophy, winner certificates and priority startup support.','TOP PRIZE',1),
('02','SECOND PLACE','Runner-up recognition, certificates and startup guidance.','RUNNER UP',2),
('03','THIRD PLACE','Second runner-up recognition, certificates and mentorship.','SECOND RUNNER UP',3);

-- ============ BENEFITS ============
create table public.benefits (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  icon text not null default 'sparkles',
  display_order int not null default 0,
  active boolean not null default true
);
grant select on public.benefits to anon;
grant select, insert, update, delete on public.benefits to authenticated;
grant all on public.benefits to service_role;
alter table public.benefits enable row level security;
create policy "benefits public read" on public.benefits for select to anon, authenticated using (true);
create policy "benefits admin write" on public.benefits for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.benefits (title, description, icon, display_order) values
('Rs 1,00,000+ FUNDING ASSISTANCE','Funding assistance for the most promising startup-ready solutions.','banknote',1),
('INCUBATION SUPPORT','Access to incubation pathways to take the project forward.','rocket',2),
('MENTORSHIP','Continued guidance from experienced mentors.','users',3),
('STARTUP GUIDANCE','Help with validation, product strategy and go-to-market.','compass',4),
('INDUSTRY CONNECTIONS','Introductions to industry practitioners and partners.','network',5),
('NETWORKING','Meet builders, founders and judges from across the country.','handshake',6);

-- ============ FAQ ============
create table public.faqs (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null default '',
  display_order int not null default 0,
  active boolean not null default true
);
grant select on public.faqs to anon;
grant select, insert, update, delete on public.faqs to authenticated;
grant all on public.faqs to service_role;
alter table public.faqs enable row level security;
create policy "faqs public read" on public.faqs for select to anon, authenticated using (true);
create policy "faqs admin write" on public.faqs for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.faqs (question, answer, display_order) values
('Who can participate?','Students who want to build and pitch a real solution. Teams come from colleges across the country.',1),
('How many members are allowed per team?','Exactly 3 members - 1 Team Lead and 2 Team Members.',2),
('How long is the hackathon?','It is a 35-hour hackathon held across 13 and 14 October 2026.',3),
('What happens on Day 1?','Day 1 is the building day - ideation, development, prototype building, mentorship and testing.',4),
('What happens on Day 2?','Day 2 is final pitching, judging, startup evaluation, results, certificates and prizes.',5),
('Who pitches the project?','The Team Lead presents the final project in front of the judges on Day 2.',6),
('What tracks are available?','Generative & Agentic AI, Health Tech, Smart Cities, Open Web Softwares, Open Innovation, Hardware / IoT and Fintech.',7),
('Is PPT submission mandatory?','Yes. Every team must upload a project presentation during registration.',8),
('What PPT formats are accepted?','Only .ppt and .pptx files uploaded directly from your device.',9),
('Where is the hackathon held?','Ghulam Ahmed Hall, Muffakham Jah College of Engineering & Technology, Banjara Hills, Hyderabad.',10),
('When are certificates distributed?','Certificates are distributed on Day 2, 14 October 2026.',11),
('What do the Top 3 winners receive?','Prizes, winner certificates and recognition, plus access to funding assistance and startup support.',12),
('Can a project become a startup?','Yes. Day 2 evaluates startup potential, and winning teams receive incubation and mentorship support.',13);

-- ============ SPONSORS ============
create table public.sponsor_tiers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  display_order int not null default 0,
  active boolean not null default true
);
grant select on public.sponsor_tiers to anon;
grant select, insert, update, delete on public.sponsor_tiers to authenticated;
grant all on public.sponsor_tiers to service_role;
alter table public.sponsor_tiers enable row level security;
create policy "tiers public read" on public.sponsor_tiers for select to anon, authenticated using (true);
create policy "tiers admin write" on public.sponsor_tiers for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.sponsor_tiers (name, display_order) values
('TITLE SPONSOR',1),('PLATINUM',2),('GOLD',3),('SILVER',4),('COMMUNITY PARTNER',5),('TECHNOLOGY PARTNER',6),('KNOWLEDGE PARTNER',7);

create table public.sponsors (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  logo_url text,
  tier_id uuid references public.sponsor_tiers(id) on delete set null,
  description text not null default '',
  website_url text,
  display_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.sponsors to anon;
grant select, insert, update, delete on public.sponsors to authenticated;
grant all on public.sponsors to service_role;
alter table public.sponsors enable row level security;
create policy "sponsors public read" on public.sponsors for select to anon, authenticated using (true);
create policy "sponsors admin write" on public.sponsors for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ============ WINNERS ============
create table public.winners (
  id uuid primary key default gen_random_uuid(),
  position int not null default 1,
  team_name text not null,
  college text not null default '',
  project_name text not null default '',
  track text not null default '',
  members text not null default '',
  prize text not null default '',
  image_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);
grant select on public.winners to anon;
grant select, insert, update, delete on public.winners to authenticated;
grant all on public.winners to service_role;
alter table public.winners enable row level security;
create policy "winners public read" on public.winners for select to anon using (published = true);
create policy "winners admin read" on public.winners for select to authenticated using (published = true or public.is_admin());
create policy "winners admin write" on public.winners for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ============ REGISTRATIONS ============
create type public.registration_status as enum ('REGISTERED','SHORTLISTED','SELECTED','REJECTED','COMPLETED');

create sequence public.registration_seq start 1;

create table public.registrations (
  id uuid primary key default gen_random_uuid(),
  registration_code text not null unique,
  team_name text not null,
  team_lead_name text not null,
  team_lead_phone text not null,
  college_name text not null,
  track_id uuid references public.tracks(id) on delete set null,
  track_name text not null default '',
  member2_name text not null,
  member3_name text not null,
  ppt_file_name text,
  ppt_file_size bigint,
  ppt_path text,
  ppt_uploaded_at timestamptz,
  status registration_status not null default 'REGISTERED',
  created_at timestamptz not null default now()
);
create unique index registrations_team_name_key on public.registrations (lower(team_name));
create unique index registrations_lead_phone_key on public.registrations (team_lead_phone);

grant insert on public.registrations to anon;
grant select, insert, update, delete on public.registrations to authenticated;
grant all on public.registrations to service_role;
grant usage on sequence public.registration_seq to anon, authenticated, service_role;
alter table public.registrations enable row level security;
create policy "public can register" on public.registrations for insert to anon, authenticated with check (true);
create policy "admins read registrations" on public.registrations for select to authenticated using (public.is_admin());
create policy "admins update registrations" on public.registrations for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admins delete registrations" on public.registrations for delete to authenticated using (public.is_admin());

create or replace function public.set_registration_code()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.registration_code is null or new.registration_code = '' then
    new.registration_code := 'IF26-' || lpad(nextval('public.registration_seq')::text, 4, '0');
  end if;
  return new;
end $$;
create trigger t_registration_code before insert on public.registrations for each row execute function public.set_registration_code();

create or replace function public.registration_open()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select registration_open and (registration_close_date is null or registration_close_date > now())
    from public.event_settings limit 1), false)
$$;

create or replace function public.guard_registration_open()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.registration_open() then
    raise exception 'Registrations are closed';
  end if;
  return new;
end $$;
create trigger t_registration_guard before insert on public.registrations for each row execute function public.guard_registration_open();