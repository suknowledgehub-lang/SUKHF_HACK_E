# Innovators Fest 2026 Hero Refresh

## Scope
- Replace only the homepage opening section; keep every section below it and all admin/CMS behavior unchanged.
- Change the fallback brand mark from “SUKH” to “SUKHF”.
- Use the uploaded SU Knowledge Hub Foundation logo in the navigation, loading screen, homepage, footer, and favicon while preserving admin-uploaded replacements.

## Homepage opening section
- Build a cinematic dark navy composition with a restrained cyan, electric-blue, violet, and magenta accent system.
- Place the event identity and actions on the left, with live date, duration, venue, and countdown details presented clearly.
- Make a futuristic Charminar the main visual on the right, generated specifically for this page rather than using the old background.
- Add restrained network particles, grid, skyline, light trails, and ambient depth without affecting the rest of the website.

## Interaction
- Add subtle cursor parallax, hover illumination, gentle float, and left/right rotation controls for the Charminar.
- Support touch drag/swipe on mobile.
- Respect reduced-motion preferences and keep animation transform-based for smooth performance.
- Keep “Register Your Team” linked to registration and “Explore Tracks” linked to the tracks section.

## Loading and branding
- Restyle the existing 0–100% loading screen to match the new opening section and display the uploaded logo.
- Update the navigation branding to read “INNOVATORS FEST 2026” beside the SUKHF mark.
- Derive a lightweight favicon from the uploaded logo.

## Validation
- Verify the opening section, loading transition, buttons, controls, and mobile layout in the running site.
- Confirm no browser errors and ensure existing sections remain unchanged.
