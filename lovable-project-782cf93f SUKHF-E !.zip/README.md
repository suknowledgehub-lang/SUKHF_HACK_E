# Innovators Fest Admin

Create the Admin access for the Innovators Fest 2026 website.

Admin login:
Email: k06265921@gmail.com
Password: Yousuf@12345

Use Supabase Authentication securely. Do NOT hard-code the password in the frontend or expose it in source code.

After successful login, redirect to /admin/dashboard and give this account full administrator permissions to manage all website content, including event details, tracks, schedule, registrations, PPT submissions, sponsors and logos, prizes, certificates, winners, FAQs, hero section, loading screen, and other CMS settings.
BUILD A COMPLETELY NEW, PRODUCTION-READY WEBSITE FROM SCRATCH FOR A PREMIUM NATIONAL-LEVEL HACKATHON AND STARTUP INNOVATION EVENT.

============================================================
EVENT IDENTITY
============================================================

EVENT NAME:
INNOVATORS FEST 2026

IMPORTANT:
The Event Name MUST be completely editable from the Admin Panel.

ORGANIZED BY:
SULTAN ULOOM KNOWLEDGE HUB

VENUE:
GHULAM AHMED HALL
MUFFAKHAM JAH COLLEGE OF ENGINEERING & TECHNOLOGY (MJCET)
BANJARA HILLS, HYDERABAD, TELANGANA

EVENT DATES:
13th & 14th October 2026

EVENT FORMAT:
35-HOUR HACKATHON

DAY 1:
13 OCTOBER 2026
BUILDING / HACKATHON DAY

DAY 2:
14 OCTOBER 2026
FINAL PITCHING
JUDGING
RESULTS
CERTIFICATES
PRIZES

IMPORTANT:
Do NOT describe this as a 48-hour hackathon.

The event is a 35-hour hackathon.

Day 1 is primarily focused on building and development.

Day 2 is focused on final pitching in front of judges, startup evaluation, results, certificates and prizes.

============================================================
OVERALL WEBSITE STYLE
============================================================

Create a HIGH-END, PREMIUM, PROFESSIONAL HACKATHON WEBSITE.

The website must NOT look like:

- a generic college event website
- a generic SaaS landing page
- an AI-generated template
- an overly colorful festival website
- a cryptocurrency website
- a childish student project

The website should feel like a serious:

NATIONAL HACKATHON
+
STARTUP INNOVATION EVENT
+
TECHNOLOGY SUMMIT

Design direction:

DARK
MINIMAL
PREMIUM
BOLD
TECHNICAL
MODERN
INTERACTIVE
ELEGANT

Use mostly:

BLACK
NEAR BLACK
DEEP NAVY
WHITE
OFF-WHITE
SOFT GREY

Use very limited accent colors such as:

subtle cyan
blue
violet

DO NOT overuse gradients.

DO NOT use huge glowing blobs.

DO NOT make everything neon.

DO NOT make every section look like an AI interface.

The website must have strong visual hierarchy, excellent typography and professional spacing.

============================================================
USE PROVIDED VISUAL REFERENCES
============================================================

The user has provided visual references for:

1. Premium dark hackathon hero
2. Hyderabad visual identity
3. Interactive hackathon track cards
4. MJCET branding
5. Sultan Uloom Knowledge Hub logo

Use these references as inspiration only.

DO NOT copy another website.

DO NOT reproduce another site's exact design.

Create an original Innovators Fest identity.

Use the PROVIDED SULTAN ULOOM KNOWLEDGE HUB LOGO where appropriate.

Use MJCET branding appropriately.

============================================================
LOADING SCREEN
============================================================

When the website first opens, display a premium loading screen.

Show:

SULTAN ULOOM KNOWLEDGE HUB LOGO

INNOVATORS FEST 2026

LOADING

0% → 100%

The loading percentage must visibly progress from 0 to 100.

After reaching 100%, smoothly transition into the main website.

Use a short professional animation.

Do not make the loading screen unnecessarily long.

Admin must be able to control:

- Loading screen enabled/disabled
- Loading logo
- Loading text

============================================================
HERO SECTION
============================================================

The HERO must be the strongest visual section of the website.

It should immediately communicate:

INNOVATORS FEST 2026

HYDERABAD

13–14 OCTOBER 2026

35-HOUR HACKATHON

GHULAM AHMED HALL
MJCET

Create a large premium title:

INNOVATORS FEST 2026

And prominently display:

HYDERABAD

in very large typography.

IMPORTANT:

DO NOT put "Namaste" or any decorative word above the event title.

The Hyderabad visual should feel like a technology/hackathon identity.

Use subtle Hyderabad-inspired architectural geometry or skyline elements if appropriate, but do NOT make the site look like a tourism website.

The primary identity must remain:

HACKATHON + INNOVATION + STARTUPS + TECHNOLOGY.

============================================================
HERO BACKGROUND
============================================================

Create a completely dark hackathon-inspired background.

Use subtle:

- technical grids
- circuit traces
- connected nodes
- particles
- engineering patterns
- digital lines
- architectural geometry
- subtle city elements
- data-like movement

The background should have depth.

Animations must be subtle and smooth.

Do not fill the screen with excessive particles.

Do not use random glowing circles everywhere.

============================================================
HERO CONTENT
============================================================

Default content:

INNOVATORS FEST 2026

HYDERABAD

13–14 OCTOBER 2026

35-HOUR HACKATHON

BUILD. PITCH. LAUNCH.

A high-impact student hackathon bringing together builders, innovators, mentors and judges to transform ideas into startup-ready solutions.

Location:

Ghulam Ahmed Hall
Muffakham Jah College of Engineering & Technology
Banjara Hills, Hyderabad

All hero content must be editable from Admin Panel.

============================================================
HERO BUTTONS
============================================================

Primary button:

REGISTER YOUR TEAM

Secondary button:

EXPLORE TRACKS

Buttons must have:

- smooth hover
- subtle elevation
- tactile click
- elegant transition
- mobile touch interaction

============================================================
COUNTDOWN
============================================================

Create an event countdown.

Show:

DAYS
HOURS
MINUTES
SECONDS

Count down toward:

13 October 2026

The countdown must update automatically.

Admin must be able to change the event start date.

============================================================
NAVIGATION
============================================================

Create a premium sticky navigation.

Left:

INNOVATORS FEST 2026

Navigation:

HOME
ABOUT
TRACKS
SCHEDULE
PRIZES
SPONSORS
FAQ

Right:

REGISTER TEAM

On scroll:

- slightly reduce navbar height
- subtle dark translucent background
- subtle blur
- smooth transition

Mobile navigation must be fully responsive.

============================================================
ABOUT SECTION
============================================================

Create a premium About section.

Default:

Innovators Fest 2026 is a 35-hour hackathon and startup innovation event designed to bring together student builders, innovators and problem solvers.

Participants build their solutions during the hackathon and present their ideas before judges on the second day.

The event focuses on innovation, technology, entrepreneurship, real-world problem solving and startup potential.

Admin must be able to edit:

- About heading
- About description
- supporting content

============================================================
35-HOUR HACKATHON STRUCTURE
============================================================

Clearly communicate:

35-HOUR HACKATHON

DAY 1 — BUILD

13 OCTOBER 2026

Focus:

Ideation
Problem Understanding
Development
Prototype Building
Mentorship
Testing
Iteration
Final Preparation

DAY 2 — PITCH

14 OCTOBER 2026

Focus:

Final Pitch
Judging
Startup Evaluation
Results
Certificates
Top 3 Awards

IMPORTANT:

The Team Lead will present the final project in front of the judges.

============================================================
TEAM STRUCTURE
============================================================

Each team consists of EXACTLY:

3 MEMBERS TOTAL

1 TEAM LEAD
2 TEAM MEMBERS

Registration fields must therefore be:

TEAM NAME

TEAM LEAD NAME

TEAM LEAD PHONE NUMBER

COLLEGE NAME

TEAM MEMBER 2 NAME

TEAM MEMBER 3 NAME

Do NOT create 3 members plus a Team Lead.

The Team Lead is one of the three members.

The Team Lead will pitch the project on Day 2.

============================================================
REGISTRATION SYSTEM
============================================================

Create a REAL registration system using Supabase.

Registration should be a premium multi-step process.

STEP 1:
Team Information

STEP 2:
Team Members

STEP 3:
Select Track

STEP 4:
Upload PPT

STEP 5:
Review

STEP 6:
Submit

============================================================
REGISTRATION FORM
============================================================

Required fields:

Team Name
Team Lead Name
Team Lead Phone Number
College Name
Track
Team Member 2
Team Member 3
Project PPT

Validate all required fields.

Phone number must have appropriate validation.

Do not allow duplicate registration submissions where appropriate.

============================================================
PPT SUBMISSION
============================================================

Every team must upload a project presentation.

Field:

UPLOAD PROJECT PPT

Supported:

.ppt
.pptx

Upload directly from the device.

DO NOT ask users to paste a PPT URL.

Use Supabase Storage.

Show:

SELECT PPT
UPLOADING
UPLOAD PROGRESS
UPLOAD SUCCESSFULLY
REPLACE PPT
REMOVE PPT

Store:

- file name
- file size
- storage path
- upload timestamp
- registration ID

PPT files must be stored securely.

Only authorized administrators should be able to access submitted PPTs.

============================================================
REGISTRATION ID
============================================================

After successful registration generate a unique registration ID.

Example:

IF26-0001
IF26-0002
IF26-0003

Display:

REGISTRATION SUCCESSFUL

Registration ID
Team Name
Team Lead
Members
College
Track
PPT Submitted

============================================================
TRACKS
============================================================

Create a dedicated premium TRACKS section.

Tracks must appear as large interactive cards.

INITIAL TRACKS:

Generative AI & Agentic AI

HEALTH TECH

SMART CITIES

OPEN WEB SOFTWARES

OPEN INNOVATION

HARDWARE / IoT

FINTECH

============================================================
TRACK DESCRIPTIONS
============================================================

Generative & Agentic AI

Artificial intelligence, AI powered applications, intelligent agents, automation and machine learning etc.

HEALTH TECH

Digital healthcare, wellness, medical technology and healthcare innovation.

SMART CITIES

Urban technology, mobility, infrastructure, sustainability and connected cities.

OPEN WEB SOFTWARES

Open web platforms, developer tools, software products and internet-based innovation.

OPEN INNOVATION

Bold ideas and solutions that do not fit into a single predefined category.

HARDWARE / IoT

Connected devices, embedded systems, sensors, robotics and hardware innovation.

FINTECH

Financial technology, digital payments, financial inclusion and smarter financial systems.

All track names and descriptions must be editable.

============================================================
TRACK CARD DESIGN
============================================================

Cards should be inspired by the provided reference.

Use:

- large visual/icon area
- track name
- short description
- subtle category label

Cards must look premium.

Use:

dark surfaces
thin borders
subtle shadows
depth
controlled accent lighting

Do not make them ordinary flat cards.

============================================================
TRACK CARD INTERACTION
============================================================

Cards must be interactive.

Desktop:

When cursor moves across a card:

- subtle 3D tilt
- perspective response
- slight elevation
- icon movement
- subtle border response

When cursor leaves:

smoothly return to normal.

Mobile:

When touched:

- subtle scale
- tactile response
- slight elevation

Do not make cards fly around.

Do not use excessive 3D.

Performance must remain smooth.

============================================================
ADMIN TRACK MANAGEMENT
============================================================

Admin must be able to:

ADD TRACK
EDIT TRACK
DELETE TRACK
ACTIVATE TRACK
DEACTIVATE TRACK
REORDER TRACKS

Fields:

Track Name
Description
Icon
Active Status
Display Order

If Admin creates:

CLIMATE TECH

it automatically appears on the public website.

If Admin disables:

FINTECH

it disappears from the public track selection.

============================================================
SCHEDULE
============================================================

Create a premium interactive schedule/timeline.

DAY 1
13 OCTOBER 2026
BUILDING / HACKATHON

DAY 2
14 OCTOBER 2026
PITCHING / JUDGING / RESULTS / CERTIFICATES / PRIZES

Create schedule events.

Example Day 1:

Registration / Check-in
Opening Ceremony
Track Briefing
Hackathon Begins
Ideation
Development
Mentor Sessions
Prototype Building
Testing
Final Preparation

Day 2:

Final Pitching
Judging
Startup Evaluation
Results
Certificate Distribution
Top 3 Winner Announcement
Prize Distribution
Closing

ALL schedule timings and descriptions must be editable from Admin Panel.

============================================================
JUDGING
============================================================

Create a professional judging section.

The Team Lead will pitch the project on Day 2.

Judging criteria may include:

Innovation
Technical Implementation
Impact
Feasibility
Scalability
Startup Potential
Presentation

Admin must be able to:

Add
Edit
Delete
Reorder
Activate/deactivate

judging criteria.

============================================================
STARTUP FOCUS
============================================================

Make it clear that Day 2 is not only about technical judging.

Judges will evaluate projects for:

Innovation
Problem-Solution Fit
Technical Execution
Market Potential
Scalability
Impact
Startup Potential
Presentation

The event should encourage teams to transform their hackathon projects into startup opportunities.

============================================================
PRIZES AND WINNER BENEFITS
============================================================

Create a major premium PRIZES section.

Highlight:

TOP 3 WINNERS

The Top 3 winning teams receive prizes and recognition.

Also highlight:

₹1,00,000+ FUNDING ASSISTANCE

INCUBATION SUPPORT

MENTORSHIP

STARTUP GUIDANCE

INDUSTRY CONNECTIONS

NETWORKING

IMPORTANT:

Use the wording:

₹1,00,000+ FUNDING ASSISTANCE

Do not falsely state that every winner is guaranteed ₹1,00,000 cash.

Admin must be able to edit all prize and benefit information.

============================================================
CERTIFICATES
============================================================

Certificates are distributed ONLY on Day 2.

Create a dedicated Certificates section or section within the Day 2 timeline.

Day 2 certificates:

PARTICIPATION CERTIFICATE

for participants.

TOP 3 WINNER CERTIFICATES

for the top three winning teams.

The website must clearly communicate that certificates are awarded/distributed on Day 2.

Admin must be able to edit:

Certificate heading
Description
Certificate types
Certificate information

============================================================
WINNERS
============================================================

Create a premium winners section.

Show:

1ST PLACE
2ND PLACE
3RD PLACE

Admin can enter:

Team Name
College
Track
Project Name
Team Members
Prize
Winner Image / Team Image (optional)

Admin can publish/unpublish winners.

The section should remain hidden if no winners have been published.

============================================================
SPONSORS — COMPLETE CMS
============================================================

Create a completely separate major:

SPONSORS

section.

This MUST NOT be static.

Sponsors must be managed entirely from Admin Panel.

============================================================
SPONSOR PUBLIC DESIGN
============================================================

Create a premium sponsor showcase.

Heading:

OUR SPONSORS

Optional subtitle:

POWERED BY INNOVATION

Use dark elegant sponsor cards.

Each sponsor card contains:

Sponsor Logo
Sponsor Name
Optional Sponsor Tier
Optional Description
Optional Website

Logo must use:

object-fit: contain

Never stretch.
Never crop.
Never distort.

============================================================
SPONSOR TIERS
============================================================

Support:

TITLE SPONSOR
PLATINUM
GOLD
SILVER
COMMUNITY PARTNER
TECHNOLOGY PARTNER
KNOWLEDGE PARTNER

Admin can create custom tiers.

Admin can:

Add
Edit
Delete
Reorder
Activate/deactivate

Sponsor tiers.

============================================================
SPONSOR ADMIN MANAGEMENT
============================================================

Admin Panel:

SPONSORS

Actions:

ADD SPONSOR
EDIT
DELETE
ACTIVATE
DEACTIVATE
REORDER

Fields:

Sponsor Name
Sponsor Logo
Sponsor Tier
Description
Website URL
Display Order
Active Status

============================================================
SPONSOR LOGO UPLOAD
============================================================

Admin must upload logos directly from their device.

DO NOT require image URLs.

Flow:

ADD SPONSOR

→ Sponsor Name

→ Upload Logo

→ Upload to Supabase Storage

→ Save Sponsor

Use Supabase Storage.

Recommended:

sponsor-logos/

Support:

PNG
JPG
JPEG
WEBP
SVG where appropriate

Maintain original aspect ratio.

============================================================
SPONSOR INTERACTION
============================================================

Desktop hover:

- slight elevation
- subtle border highlight
- soft glow
- very small scale

Mobile:

- tactile press
- subtle elevation

Keep interaction elegant.

============================================================
FAQ
============================================================

Create FAQ section.

Initial questions:

Who can participate?

How many members are allowed per team?

How long is the hackathon?

What happens on Day 1?

What happens on Day 2?

Who pitches the project?

What tracks are available?

Is PPT submission mandatory?

What PPT formats are accepted?

Where is the hackathon held?

When are certificates distributed?

What do the Top 3 winners receive?

Can a project become a startup?

All FAQs must be editable through Admin Panel.

============================================================
ADMIN PANEL
============================================================

Create a complete professional ADMIN PANEL.

Route:

/admin

Login:

/admin/login

Use Supabase Authentication.

IMPORTANT SECURITY:

Never hard-code the admin password in frontend code.

Never expose passwords in React source code.

Never expose Supabase service-role keys.

Use secure authentication and environment variables.

============================================================
ADMIN DASHBOARD
============================================================

Show:

TOTAL TEAMS
TOTAL PARTICIPANTS
ACTIVE TRACKS
PPT SUBMISSIONS
SHORTLISTED TEAMS
SELECTED TEAMS
WINNERS

Also show:

Recent Registrations
Track Distribution
Registration Activity

============================================================
ADMIN EVENT MANAGEMENT
============================================================

Admin can edit:

Event Name
Event Year
Tagline
Description
Organizer
Venue
City
Start Date
End Date
Hackathon Duration
Registration Status
Contact Information

If the Event Name changes, the entire public website should automatically update.

============================================================
ADMIN HERO MANAGEMENT
============================================================

Admin can edit:

Event Name
Year
Location
Date
Duration
Tagline
Description
Primary Button
Secondary Button
Hero assets

============================================================
ADMIN SCHEDULE MANAGEMENT
============================================================

Admin can:

Add schedule item
Edit schedule item
Delete schedule item
Reorder
Activate/deactivate

Fields:

Day
Date
Time
Title
Description
Order
Active Status

============================================================
ADMIN PRIZES MANAGEMENT
============================================================

Admin can edit:

Prize heading
Top 3 details
Funding assistance
Incubation support
Mentorship
Startup guidance
Industry support
Other benefits

============================================================
ADMIN CERTIFICATE MANAGEMENT
============================================================

Admin can manage:

Participation Certificate
Winner Certificate
Certificate descriptions
Certificate information

============================================================
ADMIN WINNER MANAGEMENT
============================================================

Admin can:

Add winner
Edit winner
Delete winner
Publish/unpublish

Winner fields:

Position
Team Name
College
Project Name
Track
Team Members
Prize
Image

============================================================
ADMIN REGISTRATION MANAGEMENT
============================================================

Create a professional registration table.

Columns:

Registration ID
Team Name
Team Lead
Phone
College
Track
Members
PPT
Status
Registration Date
Actions

Search:

Registration ID
Team Name
Team Lead
College

Filter:

Track
Status

Statuses:

REGISTERED
SHORTLISTED
SELECTED
REJECTED
COMPLETED

Admin can:

View
Edit
Delete
Change Status
Download PPT

============================================================
ADMIN PPT MANAGEMENT
============================================================

When opening a registration:

TEAM DETAILS

Team Name
Team Lead
Phone
College
Member 2
Member 3
Track

PROJECT PRESENTATION

PPT Filename
File Size
Upload Date

Button:

DOWNLOAD PPT

PPT storage must be private.

============================================================
CSV EXPORT
============================================================

Admin must be able to:

EXPORT REGISTRATIONS CSV

Include:

Registration ID
Team Name
Team Lead
Phone
College
Track
Member 2
Member 3
Status
Registration Date
PPT Filename

Do not export passwords or private credentials.

============================================================
REGISTRATION CONTROL
============================================================

Admin can:

OPEN REGISTRATION
CLOSE REGISTRATION

When registration is closed:

REGISTRATIONS ARE CLOSED

Disable form submission.

Admin can change:

Registration button text
Registration status
Registration closing date

============================================================
ORGANIZER SECTION
============================================================

Use:

SULTAN ULOOM KNOWLEDGE HUB

Use the provided official logo.

Display:

Sultan Uloom Knowledge Hub

Organizing Innovators Fest 2026

Venue:

Ghulam Ahmed Hall
Muffakham Jah College of Engineering & Technology
Banjara Hills, Hyderabad

Do not invent additional organizer information.

============================================================
FOOTER
============================================================

Create a premium footer.

Include:

INNOVATORS FEST 2026

SULTAN ULOOM KNOWLEDGE HUB

GHULAM AHMED HALL
MJCET
HYDERABAD

Navigation:

About
Tracks
Schedule
Prizes
Sponsors
FAQ
Register

Social links should be editable from Admin Panel.

============================================================
DATABASE
============================================================

Use Supabase.

Create appropriate tables:

event_settings
website_content
tracks
schedule
judging_criteria
prizes
benefits
faqs
sponsors
sponsor_tiers
registrations
winners

Use:

UUID primary keys
timestamps
active/published fields
proper relationships

============================================================
SUPABASE STORAGE
============================================================

Create storage for:

PPT PRESENTATIONS

SPONSOR LOGOS

WEBSITE ASSETS

Keep PPT presentations PRIVATE.

Sponsor logos can be publicly displayed through appropriate secure/public asset configuration.

============================================================
SECURITY
============================================================

Implement Supabase Row Level Security.

Public users:

Can view published website content.
Can view active tracks.
Can view published schedule.
Can view published sponsors.
Can submit registrations.

Administrators:

Can manage all website content.
Can manage registrations.
Can access private PPT submissions.
Can manage sponsors.
Can manage tracks.
Can manage schedule.
Can manage winners.
Can manage prizes.
Can manage FAQs.

Protect all admin routes.

Never expose:

Admin password
Supabase service-role key
Private PPT URLs
Private credentials

in frontend source code.

============================================================
FULL CMS REQUIREMENT
============================================================

The Admin Panel should allow the event organizers to operate the entire website without changing code.

Admin controls:

EVENT NAME
EVENT DETAILS
HERO
LOADING SCREEN
ABOUT
TRACKS
SCHEDULE
JUDGING
PRIZES
BENEFITS
CERTIFICATES
WINNERS
SPONSORS
SPONSOR TIERS
FAQ
REGISTRATIONS
PPT SUBMISSIONS
REGISTRATION STATUS
FOOTER
CONTACT INFORMATION
SOCIAL LINKS

============================================================
ANIMATION
============================================================

The website must be highly interactive but professional.

Use:

Smooth scroll
Scroll reveal
Subtle parallax
Card tilt
Hover effects
Touch effects
Animated counters
Countdown
Loading progress
Smooth page transitions
Interactive timeline
Subtle background movement

IMPORTANT:

Animations should respond to the user.

Do not make everything continuously move.

Do not use excessive spinning.

Do not use excessive bouncing.

Do not use excessive particles.

Do not make the website look like an AI demo.

============================================================
TRACK CARD INTERACTION
============================================================

The track cards should physically respond to:

Mouse movement
Hover
Click
Touch

Use subtle perspective.

Cursor movement should influence the card slightly.

Cards should return smoothly to their original position.

Mobile touch should provide tactile feedback.

============================================================
RESPONSIVE DESIGN
============================================================

The entire website must be responsive.

Desktop
Laptop
Tablet
Mobile

Mobile must include:

Optimized hero
Readable Hyderabad title
Responsive track cards
Touch interactions
Mobile navigation
Easy registration
PPT upload
Readable schedule
Responsive sponsor section
Responsive admin panel

No horizontal scrolling.

============================================================
ACCESSIBILITY
============================================================

Implement:

Semantic HTML
Keyboard navigation
Visible focus states
Proper form labels
Accessible buttons
Good contrast
Reduced-motion support
Accessible navigation

============================================================
PERFORMANCE
============================================================

Website must be fast.

Use:

Optimized images
Lazy loading
CSS transforms
GPU-friendly animation
Efficient React rendering
Minimal unnecessary dependencies

Avoid unnecessarily heavy 3D libraries.

============================================================
PUBLIC WEBSITE STRUCTURE
============================================================

Final public page should follow a premium flow:

1. LOADING SCREEN

2. HERO
   INNOVATORS FEST 2026
   HYDERABAD
   35-HOUR HACKATHON
   13–14 OCTOBER 2026

3. ABOUT

4. HACKATHON FORMAT
   DAY 1 BUILD
   DAY 2 PITCH

5. TRACKS

6. HOW IT WORKS

7. SCHEDULE

8. JUDGING

9. PRIZES & STARTUP BENEFITS

10. WINNERS

11. SPONSORS

12. FAQ

13. FINAL REGISTRATION CTA

14. FOOTER

============================================================
FINAL REGISTRATION CTA
============================================================

Create a powerful final CTA:

YOUR IDEA COULD BE THE NEXT BIG STARTUP.

BUILD.
PITCH.
GET RECOGNIZED.

BUTTON:

REGISTER YOUR TEAM

Make this content editable.

============================================================
IMPORTANT EVENT RULES TO DISPLAY
============================================================

35-HOUR HACKATHON

13 OCTOBER:
BUILDING / DEVELOPMENT

14 OCTOBER:
FINAL PITCHING
JUDGING
RESULTS
CERTIFICATES
PRIZES

TEAM SIZE:
3 MEMBERS

TEAM LEAD:
1

TEAM MEMBERS:
2

PITCH:
TEAM LEAD

CERTIFICATES:
DISTRIBUTED ON DAY 2

TOP 3:
PRIZES + CERTIFICATES

============================================================
FINAL QUALITY REQUIREMENT
============================================================

DO NOT CREATE A SIMPLE STATIC LANDING PAGE.

CREATE A REAL EVENT PLATFORM.

The final project must contain:

REAL SUPABASE DATABASE
REAL ADMIN AUTHENTICATION
REAL ADMIN PANEL
REAL REGISTRATION SYSTEM
REAL PPT UPLOAD
REAL PRIVATE PPT STORAGE
REAL SPONSOR MANAGEMENT
REAL SPONSOR LOGO UPLOAD
REAL TRACK MANAGEMENT
REAL SCHEDULE MANAGEMENT
REAL PRIZE MANAGEMENT
REAL WINNER MANAGEMENT
REAL FAQ MANAGEMENT
REAL CERTIFICATE CONTENT MANAGEMENT
REAL CSV EXPORT
REAL REGISTRATION STATUS MANAGEMENT

Every important public website element must be connected to the Admin Panel.

If the admin changes:

EVENT NAME

TRACK

TRACK DESCRIPTION

DATE

SCHEDULE

PRIZE

SPONSOR

SPONSOR LOGO

FAQ

WINNER

HERO TEXT

the public website must automatically reflect the change.

============================================================
CRITICAL DO-NOT-DO LIST
============================================================

DO NOT:

Create fake buttons.

Create fake registration.

Create fake PPT upload.

Create fake admin login.

Hard-code sponsor data when it should come from database.

Hard-code tracks when they should be manageable.

Expose admin credentials.

Expose service-role keys.

Store passwords in frontend code.

Use placeholder functionality and call it complete.

Make the website excessively colorful.

Make the website look AI-generated.

Use excessive gradients.

Use excessive neon.

Use unnecessary 3D.

Copy another website.

Change the event duration to 48 hours.

Change team size from 3.

Create a separate fourth team member.

Forget PPT submission.

Forget sponsor logo upload.

Forget Day 2 certificates.

Forget Top 3 prizes.

============================================================
BUILD REQUIREMENT
============================================================

BUILD THE ENTIRE WEBSITE AS A SINGLE COHESIVE PREMIUM EXPERIENCE.

Prioritize:

1. Visual quality
2. User experience
3. Real functionality
4. Admin control
5. Security
6. Performance
7. Mobile responsiveness

Do not stop after creating only the frontend.

Implement the database, authentication, storage, admin panel and public website together.

The final result should feel like a professionally produced national-level hackathon platform for:

INNOVATORS FEST 2026

SULTAN ULOOM KNOWLEDGE HUB

GHULAM AHMED HALL
MJCET
HYDERABAD

13–14 OCTOBER 2026

35-HOUR HACKATHON

BUILD. PITCH. LAUNCH.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/782cf93f-2b2c-4078-854e-a6bfee3c41ca).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
