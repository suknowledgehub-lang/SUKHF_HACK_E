import { Plus } from "lucide-react";
import { useState } from "react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import { cn } from "@/lib/utils";
import { text, type Faq as FaqRow } from "@/lib/cms";

export function Faq({
  block,
  faqs,
}: {
  block: Record<string, unknown> | undefined;
  faqs: FaqRow[];
}) {
  const active = faqs.filter((f) => f.active);
  const [open, setOpen] = useState<string | null>(active[0]?.id ?? null);
  if (!active.length) return null;

  return (
    <section id="faq" className="border-y border-border bg-surface/30">
      <div className="mx-auto max-w-4xl px-5 py-24 sm:px-8">
        <SectionHeading
          eyebrow="FAQ"
          title={text(block, "heading", "FREQUENTLY ASKED QUESTIONS")}
          subtitle={text(block, "subheading")}
        />
        <div className="mt-10 divide-y divide-border border-y border-border">
          {active.map((f) => {
            const isOpen = open === f.id;
            return (
              <div key={f.id}>
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : f.id)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 py-5 text-left"
                >
                  <span className="font-display text-base font-medium">{f.question}</span>
                  <Plus
                    size={18}
                    className={cn(
                      "shrink-0 text-primary transition-transform duration-300",
                      isOpen && "rotate-45",
                    )}
                  />
                </button>
                <div
                  className={cn(
                    "grid transition-all duration-300 ease-out",
                    isOpen ? "grid-rows-[1fr] pb-5 opacity-100" : "grid-rows-[0fr] opacity-0",
                  )}
                >
                  <p className="overflow-hidden text-sm leading-relaxed text-muted-foreground">
                    {f.answer}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
