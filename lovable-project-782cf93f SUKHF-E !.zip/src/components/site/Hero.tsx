import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, CalendarDays, MapPin, Rocket } from "lucide-react";
import { Button } from "@/components/ui/kit";
import type { EventSettings } from "@/lib/cms";
import { text } from "@/lib/cms";
import { Countdown } from "./Countdown";
import heroImage from "@/assets/hero-hackx.png.asset.json";
import neonX from "@/assets/neon-x.png.asset.json";

export function Hero({
  hero,
  settings,
}: {
  hero: Record<string, unknown> | undefined;
  settings: EventSettings;
}) {
  const headline = text(hero, "headline", settings.event_name);
  const city = text(hero, "city", settings.city);
  const dates = text(hero, "dates", settings.date_label);
  const duration = text(hero, "duration", settings.duration_label);
  const tagline = text(hero, "tagline", settings.tagline);
  const description = text(hero, "description", settings.description);
  const location = text(hero, "location", settings.venue);
  const primary = text(hero, "primary_button", settings.registration_button_text);
  const secondary = text(hero, "secondary_button", "EXPLORE TRACKS");
  const titleMatch = headline.match(/^(.*?)(FEST\s+\d{4})$/i);
  const titleLead = text(hero, "title_line1").trim() || (titleMatch?.[1]?.trim() ?? headline);
  const titleEnd = text(hero, "title_line2").trim() || (titleMatch?.[2]?.trim() ?? "");
  const eventLabel = text(hero, "label").trim() || `NATIONAL HACKATHON · ${city}`;

  const sectionRef = useRef<HTMLElement | null>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const el = sectionRef.current;
    if (!el) return;
    const onMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const nx = (e.clientX - rect.left) / rect.width - 0.5;
      const ny = (e.clientY - rect.top) / rect.height - 0.5;
      setParallax({ x: nx * 14, y: ny * 12 });
    };
    el.addEventListener("mousemove", onMove);
    return () => el.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <section
      ref={sectionRef}
      id="home"
      className="relative flex min-h-[94svh] items-center overflow-hidden pt-24 pb-10 sm:pt-28 sm:pb-14"
    >
      <div
        aria-hidden="true"
        className="hero-bg-drift pointer-events-none absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage.url})` }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-r from-background/85 via-background/35 to-transparent"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background"
      />
      <div aria-hidden="true" className="hero-bg-pulse pointer-events-none absolute inset-0" />

      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-6">
          <div className="relative z-10 pt-4 lg:pt-0">
            <div className="mb-5 flex items-center gap-3">
              <span className="h-px w-9 bg-primary" />
              <span className="font-mono text-[0.64rem] tracking-[0.24em] text-primary">
                {eventLabel}
              </span>
            </div>

            <h1 className="max-w-3xl font-display text-[12vw] leading-[0.88] font-semibold sm:text-6xl md:text-7xl lg:text-[5.3rem]">
              <span className="block">{titleLead}</span>
              {titleEnd && <span className="hero-title-accent mt-2 block">{titleEnd}</span>}
            </h1>

            <p className="mt-6 font-mono text-xs font-medium tracking-[0.3em] text-primary sm:text-sm">
              {tagline}
            </p>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              {description}
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/register">
                <Button size="lg" className="hero-cta">
                  {primary}
                  <ArrowRight size={16} />
                </Button>
              </Link>
              <a href="#tracks">
                <Button size="lg" variant="outline">
                  {secondary}
                </Button>
              </a>
            </div>

            <div className="mt-6 grid max-w-xl grid-cols-3 border border-border-strong bg-background/75 backdrop-blur-xl">
              <div className="flex flex-col border-r border-border px-3 py-3.5 sm:px-4">
                <CalendarDays size={15} className="mb-2 text-primary" />
                <p className="font-display text-[0.66rem] font-semibold sm:text-xs">{dates}</p>
                <p className="mt-auto pt-1 font-mono text-[0.5rem] tracking-[0.14em] text-muted-foreground">EVENT DATE</p>
              </div>
              <div className="flex flex-col border-r border-border px-3 py-3.5 sm:px-4">
                <MapPin size={15} className="mb-2 text-primary" />
                <p className="truncate font-display text-[0.66rem] font-semibold sm:text-xs">{location}</p>
                <p className="mt-auto pt-1 font-mono text-[0.5rem] tracking-[0.14em] text-muted-foreground">VENUE</p>
              </div>
              <div className="flex flex-col px-3 py-3.5 sm:px-4">
                <Rocket size={15} className="mb-2 text-primary" />
                <p className="font-display text-[0.66rem] font-semibold sm:text-xs">BUILD · INNOVATE · LAUNCH</p>
                <p className="mt-auto pt-1 font-mono text-[0.5rem] tracking-[0.14em] text-muted-foreground">THEME</p>
              </div>
            </div>

            <div className="mt-8 border-t border-border pt-5">
              <p className="mb-3 font-mono text-[0.6rem] tracking-[0.25em] text-muted-foreground">
                EVENT STARTS IN
              </p>
              <Countdown startDate={settings.start_date} />
            </div>
          </div>

          <div className="relative z-0 order-first flex items-center justify-center lg:order-none">
            <div
              aria-hidden="true"
              className="w-[68vw] max-w-[620px] transition-transform duration-500 ease-out sm:w-[46vw] lg:w-full"
              style={{ transform: `translate3d(${parallax.x}px, ${parallax.y}px, 0)` }}
            >
              <img
                src={neonX.url}
                alt=""
                draggable={false}
                style={{
                  maskImage:
                    "radial-gradient(ellipse 62% 62% at 50% 50%, black 45%, transparent 78%)",
                  WebkitMaskImage:
                    "radial-gradient(ellipse 62% 62% at 50% 50%, black 45%, transparent 78%)",
                }}
                className="hero-monument pointer-events-none w-full opacity-90 mix-blend-screen select-none"
              />
            </div>
          </div>
        </div>
        <div className="sr-only">{duration}. {settings.address}</div>
      </div>
    </section>
  );
}
