import { Reveal, SectionHeading } from "@/components/Reveal";
import { useSignedImage } from "@/hooks/useSignedImage";
import { text, type Sponsor, type SponsorTier } from "@/lib/cms";

function SponsorCard({ sponsor, tier }: { sponsor: Sponsor; tier?: string }) {
  const logo = useSignedImage(sponsor.logo_url, "sponsor-logos");
  const body = (
    <>
      <div className="grid h-24 place-items-center rounded-md border border-border bg-background/40 p-4">
        {logo ? (
          <img
            src={logo}
            alt={`${sponsor.name} logo`}
            className="max-h-16 w-auto max-w-full object-contain"
            loading="lazy"
          />
        ) : (
          <span className="font-display text-lg font-semibold text-muted-foreground">
            {sponsor.name}
          </span>
        )}
      </div>
      <div className="mt-4">
        {tier && <p className="eyebrow mb-1">{tier}</p>}
        <h3 className="text-sm font-semibold">{sponsor.name}</h3>
        {sponsor.description && (
          <p className="mt-1.5 text-sm text-muted-foreground">{sponsor.description}</p>
        )}
      </div>
    </>
  );

  const className =
    "panel block p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-[0_20px_50px_-30px_var(--ring)] active:scale-[0.99]";

  return sponsor.website_url ? (
    <a href={sponsor.website_url} target="_blank" rel="noreferrer noopener" className={className}>
      {body}
    </a>
  ) : (
    <div className={className}>{body}</div>
  );
}

export function Sponsors({
  block,
  sponsors,
  tiers,
}: {
  block: Record<string, unknown> | undefined;
  sponsors: Sponsor[];
  tiers: SponsorTier[];
}) {
  const active = sponsors.filter((s) => s.active);
  const tierName = new Map(tiers.map((t) => [t.id, t.name]));

  return (
    <section id="sponsors" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading
        eyebrow="PARTNERS"
        title={text(block, "heading", "OUR SPONSORS")}
        subtitle={text(block, "subheading")}
      />
      {active.length ? (
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {active.map((s, i) => (
            <Reveal key={s.id} delay={i * 50}>
              <SponsorCard
                sponsor={s}
                {...(s.tier_id && tierName.get(s.tier_id)
                  ? { tier: tierName.get(s.tier_id) as string }
                  : {})}
              />
            </Reveal>
          ))}
        </div>
      ) : (
        <Reveal className="mt-10 panel p-8 text-sm text-muted-foreground">
          Sponsor announcements are coming soon.
        </Reveal>
      )}
    </section>
  );
}
