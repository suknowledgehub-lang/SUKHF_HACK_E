import { Link } from "@tanstack/react-router";
import { ArrowRight, Award, Check, Gavel } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import { Button } from "@/components/ui/kit";
import { list, text, type Criterion, type EventSettings } from "@/lib/cms";

type Block = Record<string, unknown> | undefined;

export function About({ about, settings }: { about: Block; settings: EventSettings }) {
  const stats = list<{ label: string; value: string }>(about, "stats");
  return (
    <section id="about" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <div className="grid gap-12 lg:grid-cols-[1fr_0.85fr]">
        <div>
          <SectionHeading
            eyebrow="ABOUT"
            title={text(about, "heading", "ABOUT THE FEST")}
          />
          <Reveal delay={80}>
            <div className="mt-6 space-y-4 text-base leading-relaxed text-muted-foreground">
              {text(about, "body")
                .split("\n")
                .filter(Boolean)
                .map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
            </div>
          </Reveal>
        </div>
        <Reveal delay={140} className="grid grid-cols-2 gap-4 self-start">
          {stats.map((s) => (
            <div key={s.label} className="panel p-6">
              <p className="font-display text-4xl font-semibold text-primary">{s.value}</p>
              <p className="eyebrow mt-2">{s.label}</p>
            </div>
          ))}
          <div className="panel col-span-2 p-6">
            <p className="eyebrow mb-2">ORGANIZED BY</p>
            <p className="font-display text-lg font-semibold">{settings.organizer}</p>
            <p className="mt-1 text-sm text-muted-foreground">{settings.venue}</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Format({ format }: { format: Block }) {
  const days = [
    {
      title: text(format, "day1_title", "DAY 1 - BUILD"),
      date: text(format, "day1_date"),
      points: list<string>(format, "day1_points"),
    },
    {
      title: text(format, "day2_title", "DAY 2 - PITCH"),
      date: text(format, "day2_date"),
      points: list<string>(format, "day2_points"),
    },
  ];

  return (
    <section id="format" className="border-y border-border bg-surface/30">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <SectionHeading eyebrow="FORMAT" title={text(format, "heading", "35-HOUR HACKATHON")} />
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {days.map((d, i) => (
            <Reveal key={d.title} delay={i * 90} className="panel p-7">
              <p className="eyebrow">{d.date}</p>
              <h3 className="mt-2 font-display text-2xl font-semibold">{d.title}</h3>
              <ul className="mt-6 space-y-2.5">
                {d.points.map((p) => (
                  <li key={p} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                    <Check size={15} className="mt-0.5 shrink-0 text-primary" />
                    {p}
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
        <Reveal delay={180} className="mt-6 panel border-primary/25 p-5 text-sm text-foreground">
          {text(format, "note")}
        </Reveal>
      </div>
    </section>
  );
}

export function HowItWorks({ block }: { block: Block }) {
  const steps = list<{ title: string; description: string }>(block, "steps");
  if (!steps.length) return null;
  return (
    <section className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading eyebrow="PROCESS" title={text(block, "heading", "HOW IT WORKS")} />
      <ol className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {steps.map((s, i) => (
          <Reveal as="li" key={s.title} delay={i * 60} className="panel p-6">
            <span className="font-mono text-xs tracking-[0.2em] text-primary">
              {String(i + 1).padStart(2, "0")}
            </span>
            <h3 className="mt-3 text-lg font-semibold">{s.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{s.description}</p>
          </Reveal>
        ))}
      </ol>
    </section>
  );
}

export function Judging({ block, criteria }: { block: Block; criteria: Criterion[] }) {
  const active = criteria.filter((c) => c.active);
  if (!active.length) return null;
  return (
    <section id="judging" className="border-y border-border bg-surface/30">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <SectionHeading
          eyebrow="JUDGING"
          title={text(block, "heading", "JUDGING")}
          subtitle={text(block, "subheading")}
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {active.map((c, i) => (
            <Reveal key={c.id} delay={i * 50} className="panel flex gap-4 p-6">
              <Gavel size={18} className="mt-0.5 shrink-0 text-primary" />
              <div>
                <h3 className="font-semibold">{c.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{c.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={200} className="mt-6 text-sm text-primary">
          {text(block, "note")}
        </Reveal>
      </div>
    </section>
  );
}

export function Certificates({ block }: { block: Block }) {
  const types = list<{ title: string; description: string }>(block, "types");
  if (!types.length) return null;
  return (
    <section id="certificates" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading
        eyebrow="DAY 2"
        title={text(block, "heading", "CERTIFICATES")}
        subtitle={text(block, "subheading")}
      />
      <div className="mt-12 grid gap-5 md:grid-cols-2">
        {types.map((t, i) => (
          <Reveal key={t.title} delay={i * 80} className="panel flex gap-4 p-7">
            <Award size={22} className="mt-0.5 shrink-0 text-primary" />
            <div>
              <h3 className="text-lg font-semibold">{t.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{t.description}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function FinalCta({ block, buttonLabel }: { block: Block; buttonLabel: string }) {
  return (
    <section className="relative overflow-hidden border-y border-border">
      <div className="grid-bg absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="relative mx-auto max-w-4xl px-5 py-28 text-center sm:px-8">
        <Reveal>
          <h2 className="font-display text-3xl leading-tight font-semibold sm:text-5xl">
            {text(block, "heading")}
          </h2>
          <p className="mt-5 font-display text-sm tracking-[0.3em] text-primary">
            {text(block, "subheading")}
          </p>
          <div className="mt-10 flex justify-center">
            <Link to="/register">
              <Button size="lg">
                {text(block, "button", buttonLabel)}
                <ArrowRight size={16} />
              </Button>
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
