import { Lightbulb, Wrench } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import { participationConfig } from "@/lib/cms";

type Block = Record<string, unknown> | undefined;

export function IdeationPrototype({ block }: { block: Block }) {
  const cfg = participationConfig(block);
  if (!cfg.enabled) return null;

  const paths = [
    { key: "IDEATION", title: cfg.ideationTitle, description: cfg.ideationDescription, Icon: Lightbulb },
    { key: "PROTOTYPE", title: cfg.prototypeTitle, description: cfg.prototypeDescription, Icon: Wrench },
  ];

  return (
    <section id="ideation-or-prototype" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading eyebrow="PARTICIPATION" title={cfg.heading} subtitle={cfg.subheading} />
      <div className="mt-12 grid gap-5 md:grid-cols-2">
        {paths.map((p, i) => (
          <Reveal key={p.key} delay={i * 80} className="h-full">
            <div className="group panel relative h-full overflow-hidden p-7 transition-[transform,border-color,box-shadow] duration-300 ease-out hover:-translate-y-1 hover:border-primary/40 hover:shadow-[0_24px_60px_-30px_var(--ring)]">
              <div
                aria-hidden="true"
                className="absolute -top-16 -right-16 h-40 w-40 rounded-full bg-primary/10 blur-3xl transition-opacity duration-300 group-hover:opacity-100 md:opacity-0"
              />
              <div className="relative">
                <div className="grid h-14 w-14 place-items-center rounded-lg border border-border bg-surface-2 text-primary transition-transform duration-300 group-hover:-translate-y-1">
                  <p.Icon size={24} strokeWidth={1.6} />
                </div>
                <p className="eyebrow mt-6">PATH {String(i + 1).padStart(2, "0")}</p>
                <h3 className="mt-2 font-display text-2xl font-semibold">{p.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
