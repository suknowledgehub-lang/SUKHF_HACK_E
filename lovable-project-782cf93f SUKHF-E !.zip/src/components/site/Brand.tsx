import { useSignedImage } from "@/hooks/useSignedImage";
import { cn } from "@/lib/utils";
import logoAsset from "@/assets/sukhf-swirl.png.asset.json";

export function OrganizerMark({
  logoPath,
  size = 44,
  className,
}: {
  logoPath?: string | null | undefined;
  size?: number | undefined;
  className?: string | undefined;
}) {
  const uploadedUrl = useSignedImage(logoPath, "site-assets");
  const url = uploadedUrl ?? logoAsset.url;

  if (url) {
    return (
      <img
        src={url}
        alt="Sultan Uloom Knowledge Hub Foundation logo"
        width={size}
        height={size}
        className={cn("object-contain", className)}
        style={{ width: size, height: size }}
        loading="eager"
      />
    );
  }

  return (
    <span
      aria-hidden="true"
      className={cn(
        "grid shrink-0 place-items-center rounded-md border border-border-strong bg-surface font-display text-[0.62rem] font-bold tracking-[0.12em] text-primary",
        className,
      )}
      style={{ width: size, height: size }}
    >
      SUKHF
    </span>
  );
}
