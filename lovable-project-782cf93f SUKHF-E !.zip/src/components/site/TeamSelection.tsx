import { Loader2, PartyPopper, Search, XCircle } from "lucide-react";
import { useState } from "react";
import { SectionHeading } from "@/components/Reveal";
import { Button, Input } from "@/components/ui/kit";
import { supabase } from "@/integrations/supabase/client";

type Result =
  | { kind: "selected" | "not_selected"; code: string; team: string; college: string }
  | { kind: "missing" };

export function TeamSelection() {
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);

  const check = async () => {
    const value = code.trim();
    if (!value) return;
    setBusy(true);
    setError(null);
    setResult(null);
    const { data, error: rpcError } = await supabase.rpc("check_team_selection", {
      p_code: value,
    });
    setBusy(false);
    if (rpcError) {
      setError("Something went wrong. Please try again.");
      return;
    }
    const row = (data ?? [])[0];
    if (!row) {
      setResult({ kind: "missing" });
      return;
    }
    setResult({
      kind: row.selected ? "selected" : "not_selected",
      code: row.registration_code,
      team: row.team_name,
      college: row.college_name,
    });
  };

  return (
    <section id="team-selection" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading
        eyebrow="CHECK TEAM SELECTION"
        title="Check Team Selection"
        subtitle="Enter your Team ID to find out whether your team has been selected for the next stage of the hackathon."
      />

      <div className="panel mx-auto mt-10 max-w-2xl p-6 sm:p-8">
        <form
          className="flex flex-col gap-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            void check();
          }}
        >
          <Input
            aria-label="Enter your Team ID"
            placeholder="Enter your Team ID"
            value={code}
            onChange={(e) => setCode(e.target.value)}
          />
          <Button type="submit" disabled={busy || !code.trim()} className="shrink-0">
            {busy ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
            CHECK SELECTION
          </Button>
        </form>

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        {result?.kind === "selected" && (
          <div className="mt-6 rounded-xl border border-primary/40 bg-surface-2 p-5">
            <p className="flex items-center gap-2 font-display text-lg font-semibold text-primary">
              <PartyPopper size={18} /> Congratulations! 🎉
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Your team has been selected for the next stage of the hackathon.
            </p>
            <dl className="mt-5 grid gap-3 border-t border-border pt-4 text-sm sm:grid-cols-3">
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  TEAM ID
                </dt>
                <dd className="mt-1">{result.code}</dd>
              </div>
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  TEAM NAME
                </dt>
                <dd className="mt-1">{result.team}</dd>
              </div>
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  COLLEGE
                </dt>
                <dd className="mt-1">{result.college}</dd>
              </div>
            </dl>
          </div>
        )}

        {result?.kind === "not_selected" && (
          <div className="mt-6 rounded-xl border border-border-strong bg-surface-2 p-5">
            <p className="font-display text-base font-semibold">Your team has not been selected.</p>
            <p className="mt-2 text-sm text-muted-foreground">
              {result.code} · {result.team} · {result.college}
            </p>
          </div>
        )}

        {result?.kind === "missing" && (
          <p className="mt-6 flex items-center gap-2 text-sm text-destructive">
            <XCircle size={16} /> Team ID not found. Please check your Team ID and try again.
          </p>
        )}
      </div>
    </section>
  );
}
