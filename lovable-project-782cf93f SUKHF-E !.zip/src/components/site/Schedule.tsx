import { useState } from "react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import { cn } from "@/lib/utils";
import type { ScheduleItem } from "@/lib/cms";

export function Schedule({ items }: { items: ScheduleItem[] }) {
  const active = items.filter((i) => i.active);
  const days = Array.from(new Set(active.map((i) => i.day))).sort((a, b) => a - b);
  const [day, setDay] = useState(days[0] ?? 1);
  if (!active.length) return null;

  const dayItems = active.filter((i) => i.day === day);
  const label = dayItems[0];

  return (
    <section id="schedule" className="border-y border-border bg-surface/30">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <SectionHeading
          eyebrow="SCHEDULE"
          title="Two days. One relentless build."
          subtitle="Day 1 is for building. Day 2 is for pitching, judging, results, certificates and prizes."
        />

        <div className="mt-10 flex flex-wrap gap-2">
          {days.map((d) => {
            const sample = active.find((i) => i.day === d);
            return (
              <button
                key={d}
                type="button"
                onClick={() => setDay(d)}
                className={cn(
                  "rounded-md border px-4 py-2.5 text-left transition-colors",
                  d === day
                    ? "border-primary/50 bg-primary/10 text-foreground"
                    : "border-border text-muted-foreground hover:border-border-strong",
                )}
              >
                <span className="block font-display text-sm font-semibold">
                  {sample?.day_label ?? `DAY ${d}`}
                </span>
                <span className="font-mono text-[0.62rem] tracking-[0.18em]">
                  {sample?.date_label}
                </span>
              </button>
            );
          })}
        </div>

        {label && (
          <ol className="mt-10 border-l border-border pl-6">
            {dayItems.map((item, i) => (
              <Reveal as="li" key={item.id} delay={i * 40} className="relative pb-8 last:pb-0">
                <span
                  aria-hidden="true"
                  className="absolute top-1.5 -left-[1.6rem] h-2.5 w-2.5 rounded-full border border-primary/60 bg-background"
                />
                <p className="font-mono text-[0.68rem] tracking-[0.2em] text-primary">
                  {item.time_label}
                </p>
                <h3 className="mt-1 text-lg font-semibold">{item.title}</h3>
                {item.description && (
                  <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{item.description}</p>
                )}
              </Reveal>
            ))}
          </ol>
        )}
      </div>
    </section>
  );
}
