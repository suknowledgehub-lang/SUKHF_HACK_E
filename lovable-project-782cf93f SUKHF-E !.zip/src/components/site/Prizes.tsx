import {
  Banknote,
  Compass,
  Handshake,
  Network,
  Rocket,
  Sparkles,
  Trophy,
  Users,
  type LucideIcon,
} from "lucide-react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import { text, type Benefit, type Prize } from "@/lib/cms";

const ICONS: Record<string, LucideIcon> = {
  banknote: Banknote,
  rocket: Rocket,
  users: Users,
  compass: Compass,
  network: Network,
  handshake: Handshake,
  sparkles: Sparkles,
};

export function Prizes({
  block,
  prizes,
  benefits,
}: {
  block: Record<string, unknown> | undefined;
  prizes: Prize[];
  benefits: Benefit[];
}) {
  const activePrizes = prizes.filter((p) => p.active);
  const activeBenefits = benefits.filter((b) => b.active);

  return (
    <section id="prizes" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading
        eyebrow="PRIZES"
        title={text(block, "heading", "PRIZES & STARTUP BENEFITS")}
        subtitle={text(block, "subheading")}
      />

      <Reveal delay={60} className="mt-10 panel border-primary/30 p-8">
        <p className="eyebrow mb-3">WINNER SUPPORT</p>
        <p className="font-display text-2xl font-semibold text-primary sm:text-4xl">
          {text(block, "funding")}
        </p>
        <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
          {text(block, "funding_note")}
        </p>
      </Reveal>

      <div className="mt-6 grid gap-5 md:grid-cols-3">
        {activePrizes.map((p, i) => (
          <Reveal key={p.id} delay={i * 80} className="panel p-7">
            <div className="flex items-center justify-between">
              <span className="font-display text-4xl font-bold text-surface-2 [-webkit-text-stroke:1px_var(--border-strong)]">
                {p.position_label}
              </span>
              <Trophy size={20} className="text-primary" />
            </div>
            <h3 className="mt-5 text-lg font-semibold">{p.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{p.description}</p>
            {p.amount_label && (
              <p className="mt-4 font-mono text-[0.66rem] tracking-[0.2em] text-primary">
                {p.amount_label}
              </p>
            )}
          </Reveal>
        ))}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {activeBenefits.map((b, i) => {
          const Icon = ICONS[b.icon] ?? Sparkles;
          return (
            <Reveal key={b.id} delay={i * 50} className="panel flex gap-4 p-6">
              <Icon size={18} className="mt-0.5 shrink-0 text-primary" />
              <div>
                <h3 className="text-sm font-semibold">{b.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{b.description}</p>
              </div>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}
