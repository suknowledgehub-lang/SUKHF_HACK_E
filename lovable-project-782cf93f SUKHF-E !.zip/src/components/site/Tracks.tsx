import {
  Brain,
  Building2,
  Cpu,
  Globe,
  HeartPulse,
  Lightbulb,
  Sparkles,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import { useRef, useState } from "react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import type { Track } from "@/lib/cms";

const ICONS: Record<string, LucideIcon> = {
  brain: Brain,
  "heart-pulse": HeartPulse,
  building: Building2,
  globe: Globe,
  lightbulb: Lightbulb,
  cpu: Cpu,
  wallet: Wallet,
  sparkles: Sparkles,
};

function TrackCard({ track }: { track: Track }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [style, setStyle] = useState<{ transform: string }>({ transform: "" });
  const Icon = ICONS[track.icon] ?? Sparkles;

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setStyle({
      transform: `perspective(900px) rotateX(${(-py * 6).toFixed(2)}deg) rotateY(${(px * 8).toFixed(2)}deg) translateY(-6px)`,
    });
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setStyle({ transform: "" })}
      style={style}
      className="group panel relative h-full overflow-hidden p-6 transition-[transform,border-color,box-shadow] duration-300 ease-out will-change-transform hover:border-primary/40 hover:shadow-[0_24px_60px_-30px_var(--ring)] active:scale-[0.985]"
    >
      <div
        aria-hidden="true"
        className="absolute -top-16 -right-16 h-40 w-40 rounded-full bg-primary/10 blur-3xl transition-opacity duration-300 group-hover:opacity-100 md:opacity-0"
      />
      <div className="relative">
        <div className="grid h-14 w-14 place-items-center rounded-lg border border-border bg-surface-2 text-primary transition-transform duration-300 group-hover:-translate-y-1">
          <Icon size={24} strokeWidth={1.6} />
        </div>
        <p className="eyebrow mt-6">{track.category_label}</p>
        <h3 className="mt-2 text-xl font-semibold">{track.name}</h3>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{track.description}</p>
      </div>
    </div>
  );
}

export function Tracks({ tracks }: { tracks: Track[] }) {
  const active = tracks.filter((t) => t.active);
  if (!active.length) return null;

  return (
    <section id="tracks" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <SectionHeading
        eyebrow="TRACKS"
        title="Choose your problem space."
        subtitle="Seven tracks spanning artificial intelligence, healthcare, cities, software, hardware and finance. Pick one and build something worth pitching."
      />
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {active.map((track, i) => (
          <Reveal key={track.id} delay={i * 60} className="h-full">
            <TrackCard track={track} />
          </Reveal>
        ))}
      </div>
    </section>
  );
}
