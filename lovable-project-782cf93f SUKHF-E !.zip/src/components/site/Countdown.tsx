import { useEffect, useState } from "react";

function diff(target: number) {
  const ms = Math.max(0, target - Date.now());
  return {
    days: Math.floor(ms / 86_400_000),
    hours: Math.floor((ms / 3_600_000) % 24),
    minutes: Math.floor((ms / 60_000) % 60),
    seconds: Math.floor((ms / 1000) % 60),
  };
}

export function Countdown({ startDate }: { startDate: string }) {
  const target = new Date(startDate).getTime();
  const [time, setTime] = useState(() => diff(target));

  useEffect(() => {
    setTime(diff(target));
    const id = window.setInterval(() => setTime(diff(target)), 1000);
    return () => window.clearInterval(id);
  }, [target]);

  const units: Array<[string, number]> = [
    ["DAYS", time.days],
    ["HOURS", time.hours],
    ["MINUTES", time.minutes],
    ["SECONDS", time.seconds],
  ];

  return (
    <div className="grid w-full max-w-lg grid-cols-4 gap-2 sm:gap-3">
      {units.map(([label, value]) => (
        <div key={label} className="panel px-2 py-3 text-center sm:px-3 sm:py-4">
          <div className="font-display text-2xl font-semibold tabular-nums sm:text-3xl">
            {String(value).padStart(2, "0")}
          </div>
          <div className="mt-1 font-mono text-[0.56rem] tracking-[0.2em] text-muted-foreground sm:text-[0.62rem]">
            {label}
          </div>
        </div>
      ))}
    </div>
  );
}
