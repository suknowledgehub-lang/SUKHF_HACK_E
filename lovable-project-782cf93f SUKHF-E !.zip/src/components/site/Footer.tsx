import { Link } from "@tanstack/react-router";
import { list, text, type EventSettings } from "@/lib/cms";
import { OrganizerMark } from "./Brand";

const LINKS = [
  { label: "About", href: "#about" },
  { label: "Tracks", href: "#tracks" },
  { label: "Schedule", href: "#schedule" },
  { label: "Prizes", href: "#prizes" },
  { label: "Sponsors", href: "#sponsors" },
  { label: "FAQ", href: "#faq" },
];

export function Footer({
  settings,
  block,
}: {
  settings: EventSettings;
  block: Record<string, unknown> | undefined;
}) {
  const socials = (settings.social_links ?? []) as unknown as Array<{
    label?: string;
    url?: string;
  }>;

  return (
    <footer className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
      <div className="grid gap-10 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <OrganizerMark logoPath={settings.organizer_logo_url} size={40} />
            <span className="font-display text-sm font-semibold tracking-[0.14em]">
              {settings.event_name}
            </span>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">{settings.organizer}</p>
          <p className="mt-2 text-sm text-muted-foreground">
            {text(block, "address", settings.venue)}
          </p>
        </div>

        <nav aria-label="Footer">
          <p className="eyebrow mb-4">EXPLORE</p>
          <ul className="space-y-2.5">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <Link
                to="/register"
                className="text-sm text-primary transition-colors hover:brightness-110"
              >
                Register
              </Link>
            </li>
          </ul>
        </nav>

        <div>
          <p className="eyebrow mb-4">CONTACT</p>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            {settings.contact_email && (
              <li>
                <a href={`mailto:${settings.contact_email}`} className="hover:text-foreground">
                  {settings.contact_email}
                </a>
              </li>
            )}
            {settings.contact_phone && <li>{settings.contact_phone}</li>}
            {socials
              .filter((s) => s.url && s.label)
              .map((s) => (
                <li key={s.url}>
                  <a
                    href={s.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="hover:text-foreground"
                  >
                    {s.label}
                  </a>
                </li>
              ))}
            {list(block, "note").length === 0 && text(block, "note") && (
              <li>{text(block, "note")}</li>
            )}
          </ul>
        </div>
      </div>

      <div className="mt-12 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
        <p className="font-mono text-[0.62rem] tracking-[0.18em] text-muted-foreground">
          {settings.date_label} - {settings.city}
        </p>
        <Link
          to="/admin/login"
          className="font-mono text-[0.62rem] tracking-[0.18em] text-muted-foreground/60 hover:text-muted-foreground"
        >
          ADMIN
        </Link>
      </div>
    </footer>
  );
}
