import { useEffect, useRef } from "react";


type Node = { x: number; y: number; vx: number; vy: number };
type Pulse = { a: number; b: number; t: number; speed: number };

/**
 * Site-wide hackathon/technology background: animated node network, circuit
 * lines and data pulses. Fixed behind all content, non-interactive.
 */
export function SiteBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const styles = window.getComputedStyle(document.documentElement);
    // Deep royal purple accents, lightened slightly so the network stays legible on dark.
    const primary = "#6b2277";
    const accent = "#8b5cf6";
    void styles;

    let raf = 0;
    let width = 0;
    let height = 0;
    let nodes: Node[] = [];
    let pulses: Pulse[] = [];
    let visible = true;
    const LINK = 170;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const seedPulses = () => {
      const count = Math.min(16, Math.max(5, Math.round(nodes.length / 6)));
      pulses = Array.from({ length: count }, () => ({
        a: Math.floor(Math.random() * nodes.length),
        b: Math.floor(Math.random() * nodes.length),
        t: Math.random(),
        speed: 0.0016 + Math.random() * 0.0026,
      }));
    };

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const density = width < 640 ? 34000 : 22000;
      const count = Math.min(90, Math.max(24, Math.round((width * height) / density)));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.14,
        vy: (Math.random() - 0.5) * 0.14,
      }));
      seedPulses();
    };

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      if (!reduced) {
        for (const n of nodes) {
          n.x += n.vx;
          n.y += n.vy;
          if (n.x < 0 || n.x > width) n.vx *= -1;
          if (n.y < 0 || n.y > height) n.vy *= -1;
        }
      }

      ctx.lineWidth = 1;
      ctx.strokeStyle = primary;
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i]!;
          const b = nodes[j]!;
          const dist = Math.hypot(a.x - b.x, a.y - b.y);
          if (dist < LINK) {
            ctx.globalAlpha = 0.18 * (1 - dist / LINK);
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      ctx.fillStyle = primary;
      for (const n of nodes) {
        ctx.globalAlpha = 0.62;
        ctx.beginPath();
        ctx.arc(n.x, n.y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // data points travelling along connections
      for (const p of pulses) {
        const a = nodes[p.a];
        const b = nodes[p.b];
        if (!a || !b) continue;
        if (!reduced) p.t += p.speed;
        if (p.t > 1) {
          p.t = 0;
          p.a = Math.floor(Math.random() * nodes.length);
          p.b = Math.floor(Math.random() * nodes.length);
          continue;
        }
        const x = a.x + (b.x - a.x) * p.t;
        const y = a.y + (b.y - a.y) * p.t;
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = accent;
        ctx.beginPath();
        ctx.arc(x, y, 2.3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.globalAlpha = 1;
      if (!reduced && visible) raf = window.requestAnimationFrame(draw);
    };

    const onVisibility = () => {
      visible = !document.hidden;
      window.cancelAnimationFrame(raf);
      if (visible) draw();
    };

    resize();
    draw();
    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  return (
    <div aria-hidden="true" className="site-bg">
      <div className="site-bg-grid" />
      <div className="site-bg-circuit" />
      <div className="site-bg-beam site-bg-beam-one" />
      <div className="site-bg-beam site-bg-beam-two" />
      <div className="site-bg-wave" />
      <div className="site-bg-wave site-bg-wave-two" />
      <div className="site-bg-energy-core" />
      <canvas ref={canvasRef} className="site-bg-canvas" />
      <div className="site-bg-streak site-bg-streak-one" />
      <div className="site-bg-streak site-bg-streak-two" />
      <div className="site-bg-streak site-bg-streak-three" />
      <div className="site-bg-rings" />
      <div className="site-bg-glow" />
      <div className="site-bg-vignette" />
    </div>
  );
}
