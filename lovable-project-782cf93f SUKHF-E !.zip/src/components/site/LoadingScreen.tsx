import { useEffect, useState } from "react";
import suEmblem from "@/assets/sukhf-swirl.png.asset.json";

export function LoadingScreen({
  eventName: _eventName,
  loadingText,
  logoPath: _logoPath,
  onDone,
  hold,
}: {
  eventName: string;
  loadingText: string;
  logoPath?: string | null | undefined;
  onDone: () => void;
  hold?: boolean;
}) {
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (hold) return;
    const t1 = window.setTimeout(() => setLeaving(true), 1500);
    const t2 = window.setTimeout(onDone, 2100);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [onDone, hold]);

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed inset-0 z-100 flex flex-col items-center justify-center overflow-hidden bg-[#05030d] transition-all duration-600 ease-out ${
        leaving ? "pointer-events-none scale-[1.04] opacity-0" : "scale-100 opacity-100"
      }`}
    >
      <div className="relative flex flex-col items-center px-6 text-center">
        <div className="relative grid h-[260px] w-[260px] place-items-center sm:h-[330px] sm:w-[330px]">
          <div
            aria-hidden="true"
            className="absolute inset-6 rounded-full bg-[radial-gradient(circle,rgba(139,92,246,0.4),transparent_70%)] blur-2xl loader-breathe"
          />
          <svg
            aria-hidden="true"
            viewBox="0 0 100 100"
            className="loader-spin absolute inset-0 h-full w-full"
          >
            <circle
              cx="50"
              cy="50"
              r="46"
              fill="none"
              stroke="rgba(167,139,250,0.28)"
              strokeWidth="0.6"
            />
            <circle
              cx="50"
              cy="4"
              r="1.9"
              fill="rgb(196,181,253)"
              style={{ filter: "drop-shadow(0 0 4px rgba(167,139,250,0.95))" }}
            />
          </svg>
          <img
            src={suEmblem.url}
            alt="SU Knowledge Hub Foundation logo"
            className="loader-fade loader-breathe relative h-[82%] w-[82%] object-contain"
          />
        </div>

        <h1
          className="loader-fade font-display text-lg font-light tracking-[0.34em] text-foreground sm:text-2xl"
          style={{ animationDelay: "0.25s" }}
        >
          SU KNOWLEDGE HUB
        </h1>
        <div
          className="loader-fade mt-3 flex items-center gap-4"
          style={{ animationDelay: "0.45s" }}
        >
          <span className="h-px w-10 bg-primary/50 sm:w-16" />
          <span className="font-mono text-[0.6rem] tracking-[0.42em] text-primary sm:text-xs">
            FOUNDATION
          </span>
          <span className="h-px w-10 bg-primary/50 sm:w-16" />
        </div>

        <p className="loader-dim mt-10 font-mono text-[0.58rem] tracking-[0.38em] text-muted-foreground sm:text-[0.66rem]">
          {loadingText || "LOADING..."}
        </p>
      </div>
    </div>
  );
}
