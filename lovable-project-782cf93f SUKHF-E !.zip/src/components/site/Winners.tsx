import { Reveal, SectionHeading } from "@/components/Reveal";
import { useSignedImage } from "@/hooks/useSignedImage";
import { text, type Winner } from "@/lib/cms";

function WinnerCard({ winner }: { winner: Winner }) {
  const img = useSignedImage(winner.image_url, "site-assets");
  return (
    <div className="panel overflow-hidden">
      {img && (
        <img
          src={img}
          alt={`${winner.team_name} team`}
          className="h-44 w-full object-cover"
          loading="lazy"
        />
      )}
      <div className="p-6">
        <p className="font-mono text-[0.66rem] tracking-[0.2em] text-primary">
          {["1ST PLACE", "2ND PLACE", "3RD PLACE"][winner.position - 1] ??
            `POSITION ${winner.position}`}
        </p>
        <h3 className="mt-2 text-xl font-semibold">{winner.team_name}</h3>
        {winner.project_name && <p className="mt-1 text-sm text-foreground">{winner.project_name}</p>}
        <dl className="mt-4 space-y-1 text-sm text-muted-foreground">
          {winner.college && <dd>{winner.college}</dd>}
          {winner.track && <dd>Track: {winner.track}</dd>}
          {winner.members && <dd>Team: {winner.members}</dd>}
          {winner.prize && <dd className="text-primary">{winner.prize}</dd>}
        </dl>
      </div>
    </div>
  );
}

export function Winners({
  block,
  winners,
}: {
  block: Record<string, unknown> | undefined;
  winners: Winner[];
}) {
  const published = winners.filter((w) => w.published);
  if (!published.length) return null;

  return (
    <section id="winners" className="border-y border-border bg-surface/30">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <SectionHeading
          eyebrow="RESULTS"
          title={text(block, "heading", "WINNERS")}
          subtitle={text(block, "subheading")}
        />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {published.map((w, i) => (
            <Reveal key={w.id} delay={i * 80}>
              <WinnerCard winner={w} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
