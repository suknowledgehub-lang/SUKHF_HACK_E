import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronUp, Loader2, Plus, Trash2, Upload } from "lucide-react";
import { useState } from "react";
import { Button, Field, Input, Select, Textarea, Toggle } from "@/components/ui/kit";
import { useSignedImage } from "@/hooks/useSignedImage";
import { supabase } from "@/integrations/supabase/client";

// Generic CMS editor works across many tables, so queries are dynamically typed.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export type FieldDef = {
  name: string;
  label: string;
  type?: "text" | "textarea" | "number" | "boolean" | "select" | "image";
  options?: Array<{ value: string; label: string }>;
  bucket?: string;
  full?: boolean;
};

type Row = Record<string, unknown> & { id: string };

function ImageField({
  value,
  bucket,
  onChange,
}: {
  value: string | null;
  bucket: string;
  onChange: (path: string | null) => void;
}) {
  const url = useSignedImage(value, bucket);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const upload = async (file: File) => {
    setError(null);
    setBusy(true);
    const path = `${crypto.randomUUID()}/${file.name.replace(/[^\w.\- ]+/g, "_")}`;
    const { error: upErr } = await supabase.storage
      .from(bucket)
      .upload(path, file, file.type ? { contentType: file.type } : {});
    setBusy(false);
    if (upErr) {
      setError(upErr.message);
      return;
    }
    onChange(path);
  };

  return (
    <div className="space-y-2">
      {url && (
        <img
          src={url}
          alt="Uploaded asset preview"
          className="h-20 w-auto max-w-full rounded border border-border bg-background object-contain p-2"
        />
      )}
      <div className="flex items-center gap-2">
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border-strong px-3 py-2 text-xs hover:border-primary/60">
          {busy ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
          {value ? "REPLACE IMAGE" : "UPLOAD IMAGE"}
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp,image/svg+xml"
            className="sr-only"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void upload(f);
            }}
          />
        </label>
        {value && (
          <Button type="button" size="sm" variant="ghost" onClick={() => onChange(null)}>
            REMOVE
          </Button>
        )}
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

export function CollectionEditor({
  title,
  description,
  table,
  fields,
  defaults,
  orderBy = "display_order",
  titleField = "name",
}: {
  title: string;
  description?: string;
  table: string;
  fields: FieldDef[];
  defaults: Record<string, unknown>;
  orderBy?: string;
  titleField?: string;
}) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState<Record<string, unknown>>({});
  const [error, setError] = useState<string | null>(null);

  const rows = useQuery({
    queryKey: [table],
    queryFn: async () => {
      const { data, error: qErr } = await db.from(table).select("*").order(orderBy);
      if (qErr) throw new Error(qErr.message);
      return (data ?? []) as Row[];
    },
  });

  const invalidate = () => void qc.invalidateQueries({ queryKey: [table] });

  const save = useMutation({
    mutationFn: async (payload: Record<string, unknown>) => {
      setError(null);
      if (payload["id"]) {
        const { id, ...rest } = payload;
        const { error: e } = await db.from(table).update(rest).eq("id", id as string);
        if (e) throw new Error(e.message);
      } else {
        const { error: e } = await db.from(table).insert(payload);
        if (e) throw new Error(e.message);
      }
    },
    onSuccess: () => {
      setEditing(null);
      setDraft({});
      invalidate();
    },
    onError: (e: Error) => setError(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error: e } = await db.from(table).delete().eq("id", id);
      if (e) throw new Error(e.message);
    },
    onSuccess: invalidate,
    onError: (e: Error) => setError(e.message),
  });

  const reorder = useMutation({
    mutationFn: async ({ row, dir }: { row: Row; dir: -1 | 1 }) => {
      const list = rows.data ?? [];
      const idx = list.findIndex((r) => r.id === row.id);
      const swap = list[idx + dir];
      if (!swap) return;
      await db
        .from(table)
        .update({ [orderBy]: swap[orderBy] as number })
        .eq("id", row.id);
      await db
        .from(table)
        .update({ [orderBy]: row[orderBy] as number })
        .eq("id", swap.id);
    },
    onSuccess: invalidate,
  });

  const startNew = () => {
    const max = Math.max(0, ...(rows.data ?? []).map((r) => Number(r[orderBy] ?? 0)));
    setDraft({ ...defaults, [orderBy]: max + 1 });
    setEditing("new");
  };

  const renderForm = () => (
    <div className="panel space-y-4 p-5">
      <div className="grid gap-4 sm:grid-cols-2">
        {fields.map((f) => {
          const value = draft[f.name];
          return (
            <div key={f.name} className={f.full || f.type === "textarea" ? "sm:col-span-2" : ""}>
              {f.type === "boolean" ? (
                <div className="flex items-center gap-3 pt-6">
                  <Toggle
                    label={f.label}
                    checked={!!value}
                    onChange={(v) => setDraft((d) => ({ ...d, [f.name]: v }))}
                  />
                  <span className="text-sm">{f.label}</span>
                </div>
              ) : (
                <Field label={f.label}>
                  {f.type === "textarea" ? (
                    <Textarea
                      value={String(value ?? "")}
                      onChange={(e) => setDraft((d) => ({ ...d, [f.name]: e.target.value }))}
                    />
                  ) : f.type === "select" ? (
                    <Select
                      value={String(value ?? "")}
                      onChange={(e) =>
                        setDraft((d) => ({ ...d, [f.name]: e.target.value || null }))
                      }
                    >
                      <option value="">-</option>
                      {(f.options ?? []).map((o) => (
                        <option key={o.value} value={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </Select>
                  ) : f.type === "image" ? (
                    <ImageField
                      value={(value as string) ?? null}
                      bucket={f.bucket ?? "site-assets"}
                      onChange={(p) => setDraft((d) => ({ ...d, [f.name]: p }))}
                    />
                  ) : (
                    <Input
                      type={f.type === "number" ? "number" : "text"}
                      value={String(value ?? "")}
                      onChange={(e) =>
                        setDraft((d) => ({
                          ...d,
                          [f.name]: f.type === "number" ? Number(e.target.value) : e.target.value,
                        }))
                      }
                    />
                  )}
                </Field>
              )}
            </div>
          );
        })}
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex gap-2">
        <Button size="sm" disabled={save.isPending} onClick={() => save.mutate(draft)}>
          {save.isPending && <Loader2 size={14} className="animate-spin" />} SAVE
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            setEditing(null);
            setDraft({});
          }}
        >
          CANCEL
        </Button>
      </div>
    </div>
  );

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-semibold">{title}</h2>
          {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
        </div>
        <Button size="sm" onClick={startNew}>
          <Plus size={14} /> ADD
        </Button>
      </div>

      {editing === "new" && renderForm()}

      <div className="space-y-3">
        {(rows.data ?? []).map((row) => (
          <div key={row.id}>
            {editing === row.id ? (
              renderForm()
            ) : (
              <div className="panel flex flex-wrap items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <p className="truncate font-medium">
                    {String(row[titleField] ?? row["title"] ?? row["question"] ?? "Untitled")}
                  </p>
                  <p className="mt-0.5 font-mono text-[0.62rem] tracking-[0.16em] text-muted-foreground">
                    #{String(row[orderBy] ?? "")} ·{" "}
                    {row["active"] === false || row["published"] === false ? "HIDDEN" : "VISIBLE"}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    aria-label="Move up"
                    onClick={() => reorder.mutate({ row, dir: -1 })}
                  >
                    <ChevronUp size={15} />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    aria-label="Move down"
                    onClick={() => reorder.mutate({ row, dir: 1 })}
                  >
                    <ChevronDown size={15} />
                  </Button>
                  <Button
                    size="sm"
                    variant="subtle"
                    onClick={() => {
                      setDraft(row);
                      setEditing(row.id);
                    }}
                  >
                    EDIT
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    aria-label="Delete"
                    onClick={() => {
                      if (window.confirm("Delete this item?")) remove.mutate(row.id);
                    }}
                  >
                    <Trash2 size={15} />
                  </Button>
                </div>
              </div>
            )}
          </div>
        ))}
        {rows.isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
      </div>
    </section>
  );
}
