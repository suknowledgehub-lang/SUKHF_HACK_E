import { useEffect, useState } from "react";
import { signedUrl } from "@/lib/cms";

export function useSignedImage(path: string | null | undefined, bucket: string) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    if (!path) {
      setUrl(null);
      return;
    }
    signedUrl(path, bucket).then((u) => {
      if (alive) setUrl(u);
    });
    return () => {
      alive = false;
    };
  }, [path, bucket]);

  return url;
}
