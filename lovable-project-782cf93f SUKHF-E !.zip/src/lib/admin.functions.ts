import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(10).max(200),
});

/**
 * One-time setup for the allow-listed administrator account.
 * The password is supplied by the person running setup and is never stored in
 * source code; it goes straight to the auth service.
 */
export const bootstrapAdmin = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => schema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const email = data.email.toLowerCase();

    const { data: allow } = await supabaseAdmin
      .from("admin_allowlist")
      .select("email")
      .eq("email", email)
      .maybeSingle();

    if (!allow) throw new Error("This email is not authorized for admin setup.");

    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: data.password,
      email_confirm: true,
    });

    let userId = created?.user?.id ?? null;

    if (error) {
      const { data: existing } = await supabaseAdmin.auth.admin.listUsers();
      const match = existing?.users.find((u) => u.email?.toLowerCase() === email);
      if (!match) throw new Error(error.message);
      userId = match.id;
    }

    if (!userId) throw new Error("Could not create the administrator account.");

    const { error: roleError } = await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: userId, role: "admin" }, { onConflict: "user_id,role" });
    if (roleError) throw new Error(roleError.message);

    return { created: !error };
  });
