import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";
const SPREADSHEET_TITLE = "Hackathon Registrations";
const SHEET_TITLE = "Registrations";
const STATE_KEY = "google_sheets_registrations";

const HEADERS = [
  "Registration ID",
  "Team Name",
  "Team Lead",
  "Team Lead Phone",
  "College",
  "Track",
  "Participation Type",
  "Member 2",
  "Member 3",
  "PPT File",
  "PPT Size (MB)",
  "Status",
  "Registered At",
];

function authHeaders() {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const connectionKey = process.env["GOOGLE_SHEETS_API_KEY"];
  if (!lovableKey || !connectionKey) {
    throw new Error("Google Sheets connection is not configured for this project.");
  }
  return {
    Authorization: `Bearer ${lovableKey}`,
    "X-Connection-Api-Key": connectionKey,
    "Content-Type": "application/json",
  };
}

async function sheetsFetch(path: string, init?: RequestInit) {
  const response = await fetch(`${GATEWAY}${path}`, {
    ...init,
    headers: { ...authHeaders(), ...(init?.headers ?? {}) },
  });
  const text = await response.text();
  if (!response.ok) {
    console.error(`[GoogleSheets] ${path} failed [${response.status}]: ${text}`);
    throw new Error(`Google Sheets request failed [${response.status}]: ${text}`);
  }
  return text ? JSON.parse(text) : {};
}

type Admin = Awaited<
  typeof import("@/integrations/supabase/client.server")
>["supabaseAdmin"];

/** Returns the id of the single "Hackathon Registrations" spreadsheet, creating it once if needed. */
async function ensureSpreadsheet(supabaseAdmin: Admin): Promise<string> {
  const { data: state } = await supabaseAdmin
    .from("integration_state")
    .select("value")
    .eq("key", STATE_KEY)
    .maybeSingle();

  const storedId = (state?.value as { spreadsheet_id?: string } | null)?.spreadsheet_id;

  if (storedId) {
    const meta = await sheetsFetch(`/spreadsheets/${storedId}?fields=sheets.properties.title`);
    const titles: string[] = (meta.sheets ?? []).map(
      (s: { properties?: { title?: string } }) => s.properties?.title ?? "",
    );
    if (!titles.includes(SHEET_TITLE)) {
      await sheetsFetch(`/spreadsheets/${storedId}:batchUpdate`, {
        method: "POST",
        body: JSON.stringify({
          requests: [{ addSheet: { properties: { title: SHEET_TITLE } } }],
        }),
      });
      await sheetsFetch(`/spreadsheets/${storedId}/values/${SHEET_TITLE}!A1:M1?valueInputOption=RAW`, {
        method: "PUT",
        body: JSON.stringify({ values: [HEADERS] }),
      });
    }
    await sheetsFetch(`/spreadsheets/${storedId}/values/${SHEET_TITLE}!A1:M1?valueInputOption=RAW`, {
      method: "PUT",
      body: JSON.stringify({ values: [HEADERS] }),
    });
    return storedId;
  }

  const created = await sheetsFetch(`/spreadsheets`, {
    method: "POST",
    body: JSON.stringify({
      properties: { title: SPREADSHEET_TITLE },
      sheets: [{ properties: { title: SHEET_TITLE } }],
    }),
  });

  const spreadsheetId: string = created.spreadsheetId;

  await sheetsFetch(`/spreadsheets/${spreadsheetId}/values/${SHEET_TITLE}!A1:M1?valueInputOption=RAW`, {
    method: "PUT",
    body: JSON.stringify({ values: [HEADERS] }),
  });

  await supabaseAdmin
    .from("integration_state")
    .upsert(
      { key: STATE_KEY, value: { spreadsheet_id: spreadsheetId }, updated_at: new Date().toISOString() },
      { onConflict: "key" },
    );

  return spreadsheetId;
}

const schema = z.object({
  registration_code: z.string().trim().min(3).max(64),
});

/**
 * Appends one registration to the shared "Hackathon Registrations" spreadsheet.
 * Safe to call more than once: a registration that already has a synced row is skipped.
 */
export const syncRegistrationToSheet = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => schema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: row, error } = await supabaseAdmin
      .from("registrations")
      .select("*")
      .eq("registration_code", data.registration_code)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!row) throw new Error("Registration not found.");
    if (row.sheet_synced_at) return { synced: false, alreadySynced: true };

    const spreadsheetId = await ensureSpreadsheet(supabaseAdmin);

    const values = [
      [
        row.registration_code,
        row.team_name,
        row.team_lead_name,
        row.team_lead_phone,
        row.college_name,
        row.track_name,
        row.participation_type ?? "",
        row.member2_name,
        row.member3_name,
        row.ppt_file_name ?? "",
        row.ppt_file_size ? (row.ppt_file_size / 1024 / 1024).toFixed(2) : "",
        row.status,
        new Date(row.created_at).toISOString(),
      ],
    ];

    const appended = await sheetsFetch(
      `/spreadsheets/${spreadsheetId}/values/${SHEET_TITLE}!A:M:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
      { method: "POST", body: JSON.stringify({ values }) },
    );

    const updatedRange: string = appended.updates?.updatedRange ?? "";
    const rowNumber = Number(updatedRange.match(/!A(\d+)/)?.[1] ?? 0) || null;

    await supabaseAdmin
      .from("registrations")
      .update({ sheet_synced_at: new Date().toISOString(), sheet_row_number: rowNumber })
      .eq("id", row.id);

    return { synced: true, alreadySynced: false };
  });
