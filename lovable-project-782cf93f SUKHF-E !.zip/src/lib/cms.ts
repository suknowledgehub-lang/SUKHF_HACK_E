import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type EventSettings = Tables<"event_settings">;
export type Track = Tables<"tracks">;
export type ScheduleItem = Tables<"schedule_items">;
export type Criterion = Tables<"judging_criteria">;
export type Prize = Tables<"prizes">;
export type Benefit = Tables<"benefits">;
export type Faq = Tables<"faqs">;
export type Sponsor = Tables<"sponsors">;
export type SponsorTier = Tables<"sponsor_tiers">;
export type Winner = Tables<"winners">;
export type Registration = Tables<"registrations">;

export type ContentMap = Record<string, Record<string, unknown>>;

async function must<T>(p: PromiseLike<{ data: T | null; error: { message: string } | null }>) {
  const { data, error } = await p;
  if (error) throw new Error(error.message);
  return data as T;
}

export const settingsQuery = queryOptions({
  queryKey: ["event_settings"],
  queryFn: async () =>
    must<EventSettings>(supabase.from("event_settings").select("*").limit(1).single()),
  staleTime: 30_000,
});

export const contentQuery = queryOptions({
  queryKey: ["site_content"],
  queryFn: async () => {
    const rows = await must<Tables<"site_content">[]>(supabase.from("site_content").select("*"));
    const map: ContentMap = {};
    for (const row of rows) map[row.key] = (row.value ?? {}) as Record<string, unknown>;
    return map;
  },
  staleTime: 30_000,
});

export const tracksQuery = queryOptions({
  queryKey: ["tracks"],
  queryFn: async () =>
    must<Track[]>(supabase.from("tracks").select("*").order("display_order")),
  staleTime: 30_000,
});

export const scheduleQuery = queryOptions({
  queryKey: ["schedule_items"],
  queryFn: async () =>
    must<ScheduleItem[]>(supabase.from("schedule_items").select("*").order("display_order")),
  staleTime: 30_000,
});

export const criteriaQuery = queryOptions({
  queryKey: ["judging_criteria"],
  queryFn: async () =>
    must<Criterion[]>(supabase.from("judging_criteria").select("*").order("display_order")),
  staleTime: 30_000,
});

export const prizesQuery = queryOptions({
  queryKey: ["prizes"],
  queryFn: async () => must<Prize[]>(supabase.from("prizes").select("*").order("display_order")),
  staleTime: 30_000,
});

export const benefitsQuery = queryOptions({
  queryKey: ["benefits"],
  queryFn: async () =>
    must<Benefit[]>(supabase.from("benefits").select("*").order("display_order")),
  staleTime: 30_000,
});

export const faqsQuery = queryOptions({
  queryKey: ["faqs"],
  queryFn: async () => must<Faq[]>(supabase.from("faqs").select("*").order("display_order")),
  staleTime: 30_000,
});

export const sponsorsQuery = queryOptions({
  queryKey: ["sponsors"],
  queryFn: async () =>
    must<Sponsor[]>(supabase.from("sponsors").select("*").order("display_order")),
  staleTime: 30_000,
});

export const sponsorTiersQuery = queryOptions({
  queryKey: ["sponsor_tiers"],
  queryFn: async () =>
    must<SponsorTier[]>(supabase.from("sponsor_tiers").select("*").order("display_order")),
  staleTime: 30_000,
});

export const winnersQuery = queryOptions({
  queryKey: ["winners"],
  queryFn: async () => must<Winner[]>(supabase.from("winners").select("*").order("position")),
  staleTime: 30_000,
});

export const registrationsQuery = queryOptions({
  queryKey: ["registrations"],
  queryFn: async () =>
    must<Registration[]>(
      supabase.from("registrations").select("*").order("created_at", { ascending: false }),
    ),
});

export function text(block: Record<string, unknown> | undefined, key: string, fallback = "") {
  const v = block?.[key];
  return typeof v === "string" ? v : fallback;
}

export function list<T = Record<string, unknown>>(
  block: Record<string, unknown> | undefined,
  key: string,
): T[] {
  const v = block?.[key];
  return Array.isArray(v) ? (v as T[]) : [];
}

export type ParticipationType = "IDEATION" | "PROTOTYPE";

export const PARTICIPATION_CONTENT_KEY = "ideation_prototype";

const bool = (block: Record<string, unknown> | undefined, key: string) =>
  block?.[key] === undefined ? true : block[key] === true;

export function participationConfig(block: Record<string, unknown> | undefined) {
  return {
    enabled: bool(block, "enabled"),
    heading: text(block, "heading", "IDEATION OR PROTOTYPE"),
    subheading: text(
      block,
      "subheading",
      "Turn your idea into impact — or bring your prototype to life.",
    ),
    ideationTitle: text(block, "ideation_title", "IDEATION"),
    ideationDescription: text(
      block,
      "ideation_description",
      "For participants who have an innovative idea and want to develop, validate, and present their concept.",
    ),
    prototypeTitle: text(block, "prototype_title", "PROTOTYPE"),
    prototypeDescription: text(
      block,
      "prototype_description",
      "For participants who already have a concept or solution and want to build, demonstrate, and refine a working prototype.",
    ),
    ideationRegistrationEnabled: bool(block, "ideation_registration_enabled"),
    prototypeRegistrationEnabled: bool(block, "prototype_registration_enabled"),
  };
}

export const participationQuery = queryOptions({
  queryKey: ["site_content", PARTICIPATION_CONTENT_KEY],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("site_content")
      .select("value")
      .eq("key", PARTICIPATION_CONTENT_KEY)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return (data?.value ?? {}) as Record<string, unknown>;
  },
  staleTime: 30_000,
});

const signedCache = new Map<string, string>();

export async function signedUrl(path: string | null | undefined, bucket: string) {
  if (!path) return null;
  if (path.startsWith("http")) return path;
  const cacheKey = `${bucket}/${path}`;
  const cached = signedCache.get(cacheKey);
  if (cached) return cached;
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60 * 24);
  if (data?.signedUrl) signedCache.set(cacheKey, data.signedUrl);
  return data?.signedUrl ?? null;
}
