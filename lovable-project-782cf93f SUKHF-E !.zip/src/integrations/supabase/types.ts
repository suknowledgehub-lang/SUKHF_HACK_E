export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_allowlist: {
        Row: {
          created_at: string
          email: string
        }
        Insert: {
          created_at?: string
          email: string
        }
        Update: {
          created_at?: string
          email?: string
        }
        Relationships: []
      }
      benefits: {
        Row: {
          active: boolean
          description: string
          display_order: number
          icon: string
          id: string
          title: string
        }
        Insert: {
          active?: boolean
          description?: string
          display_order?: number
          icon?: string
          id?: string
          title: string
        }
        Update: {
          active?: boolean
          description?: string
          display_order?: number
          icon?: string
          id?: string
          title?: string
        }
        Relationships: []
      }
      event_settings: {
        Row: {
          address: string
          city: string
          contact_email: string
          contact_phone: string
          date_label: string
          description: string
          duration_label: string
          end_date: string
          event_name: string
          event_year: string
          id: string
          loading_enabled: boolean
          loading_logo_url: string | null
          loading_text: string
          organizer: string
          organizer_logo_url: string | null
          registration_button_text: string
          registration_close_date: string | null
          registration_open: boolean
          singleton: boolean
          social_links: Json
          start_date: string
          tagline: string
          updated_at: string
          venue: string
        }
        Insert: {
          address?: string
          city?: string
          contact_email?: string
          contact_phone?: string
          date_label?: string
          description?: string
          duration_label?: string
          end_date?: string
          event_name?: string
          event_year?: string
          id?: string
          loading_enabled?: boolean
          loading_logo_url?: string | null
          loading_text?: string
          organizer?: string
          organizer_logo_url?: string | null
          registration_button_text?: string
          registration_close_date?: string | null
          registration_open?: boolean
          singleton?: boolean
          social_links?: Json
          start_date?: string
          tagline?: string
          updated_at?: string
          venue?: string
        }
        Update: {
          address?: string
          city?: string
          contact_email?: string
          contact_phone?: string
          date_label?: string
          description?: string
          duration_label?: string
          end_date?: string
          event_name?: string
          event_year?: string
          id?: string
          loading_enabled?: boolean
          loading_logo_url?: string | null
          loading_text?: string
          organizer?: string
          organizer_logo_url?: string | null
          registration_button_text?: string
          registration_close_date?: string | null
          registration_open?: boolean
          singleton?: boolean
          social_links?: Json
          start_date?: string
          tagline?: string
          updated_at?: string
          venue?: string
        }
        Relationships: []
      }
      faqs: {
        Row: {
          active: boolean
          answer: string
          display_order: number
          id: string
          question: string
        }
        Insert: {
          active?: boolean
          answer?: string
          display_order?: number
          id?: string
          question: string
        }
        Update: {
          active?: boolean
          answer?: string
          display_order?: number
          id?: string
          question?: string
        }
        Relationships: []
      }
      integration_state: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      judging_criteria: {
        Row: {
          active: boolean
          description: string
          display_order: number
          id: string
          title: string
        }
        Insert: {
          active?: boolean
          description?: string
          display_order?: number
          id?: string
          title: string
        }
        Update: {
          active?: boolean
          description?: string
          display_order?: number
          id?: string
          title?: string
        }
        Relationships: []
      }
      prizes: {
        Row: {
          active: boolean
          amount_label: string
          description: string
          display_order: number
          id: string
          position_label: string
          title: string
        }
        Insert: {
          active?: boolean
          amount_label?: string
          description?: string
          display_order?: number
          id?: string
          position_label: string
          title?: string
        }
        Update: {
          active?: boolean
          amount_label?: string
          description?: string
          display_order?: number
          id?: string
          position_label?: string
          title?: string
        }
        Relationships: []
      }
      registrations: {
        Row: {
          college_name: string
          created_at: string
          id: string
          member2_name: string
          member3_name: string
          participation_type: string | null
          ppt_file_name: string | null
          ppt_file_size: number | null
          ppt_path: string | null
          ppt_uploaded_at: string | null
          registration_code: string
          selected: boolean
          sheet_row_number: number | null
          sheet_synced_at: string | null
          status: Database["public"]["Enums"]["registration_status"]
          team_lead_name: string
          team_lead_phone: string
          team_name: string
          track_id: string | null
          track_name: string
        }
        Insert: {
          college_name: string
          created_at?: string
          id?: string
          member2_name: string
          member3_name: string
          participation_type?: string | null
          ppt_file_name?: string | null
          ppt_file_size?: number | null
          ppt_path?: string | null
          ppt_uploaded_at?: string | null
          registration_code: string
          selected?: boolean
          sheet_row_number?: number | null
          sheet_synced_at?: string | null
          status?: Database["public"]["Enums"]["registration_status"]
          team_lead_name: string
          team_lead_phone: string
          team_name: string
          track_id?: string | null
          track_name?: string
        }
        Update: {
          college_name?: string
          created_at?: string
          id?: string
          member2_name?: string
          member3_name?: string
          participation_type?: string | null
          ppt_file_name?: string | null
          ppt_file_size?: number | null
          ppt_path?: string | null
          ppt_uploaded_at?: string | null
          registration_code?: string
          selected?: boolean
          sheet_row_number?: number | null
          sheet_synced_at?: string | null
          status?: Database["public"]["Enums"]["registration_status"]
          team_lead_name?: string
          team_lead_phone?: string
          team_name?: string
          track_id?: string | null
          track_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "registrations_track_id_fkey"
            columns: ["track_id"]
            isOneToOne: false
            referencedRelation: "tracks"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_items: {
        Row: {
          active: boolean
          created_at: string
          date_label: string
          day: number
          day_label: string
          description: string
          display_order: number
          id: string
          time_label: string
          title: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          date_label?: string
          day?: number
          day_label?: string
          description?: string
          display_order?: number
          id?: string
          time_label?: string
          title: string
        }
        Update: {
          active?: boolean
          created_at?: string
          date_label?: string
          day?: number
          day_label?: string
          description?: string
          display_order?: number
          id?: string
          time_label?: string
          title?: string
        }
        Relationships: []
      }
      site_content: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      sponsor_tiers: {
        Row: {
          active: boolean
          display_order: number
          id: string
          name: string
        }
        Insert: {
          active?: boolean
          display_order?: number
          id?: string
          name: string
        }
        Update: {
          active?: boolean
          display_order?: number
          id?: string
          name?: string
        }
        Relationships: []
      }
      sponsors: {
        Row: {
          active: boolean
          created_at: string
          description: string
          display_order: number
          id: string
          logo_url: string | null
          name: string
          tier_id: string | null
          website_url: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string
          display_order?: number
          id?: string
          logo_url?: string | null
          name: string
          tier_id?: string | null
          website_url?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string
          display_order?: number
          id?: string
          logo_url?: string | null
          name?: string
          tier_id?: string | null
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sponsors_tier_id_fkey"
            columns: ["tier_id"]
            isOneToOne: false
            referencedRelation: "sponsor_tiers"
            referencedColumns: ["id"]
          },
        ]
      }
      tracks: {
        Row: {
          active: boolean
          category_label: string
          created_at: string
          description: string
          display_order: number
          icon: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          category_label?: string
          created_at?: string
          description?: string
          display_order?: number
          icon?: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          category_label?: string
          created_at?: string
          description?: string
          display_order?: number
          icon?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      winners: {
        Row: {
          college: string
          created_at: string
          id: string
          image_url: string | null
          members: string
          position: number
          prize: string
          project_name: string
          published: boolean
          team_name: string
          track: string
        }
        Insert: {
          college?: string
          created_at?: string
          id?: string
          image_url?: string | null
          members?: string
          position?: number
          prize?: string
          project_name?: string
          published?: boolean
          team_name: string
          track?: string
        }
        Update: {
          college?: string
          created_at?: string
          id?: string
          image_url?: string | null
          members?: string
          position?: number
          prize?: string
          project_name?: string
          published?: boolean
          team_name?: string
          track?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_team_selection: {
        Args: { p_code: string }
        Returns: {
          college_name: string
          registration_code: string
          selected: boolean
          team_name: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
      registration_open: { Args: never; Returns: boolean }
      submit_registration:
        | {
            Args: {
              p_college_name: string
              p_member2_name: string
              p_member3_name: string
              p_ppt_file_name: string
              p_ppt_file_size: number
              p_ppt_path: string
              p_team_lead_name: string
              p_team_lead_phone: string
              p_team_name: string
              p_track_id: string
              p_track_name: string
            }
            Returns: string
          }
        | {
            Args: {
              p_college_name: string
              p_member2_name: string
              p_member3_name: string
              p_participation_type?: string
              p_ppt_file_name: string
              p_ppt_file_size: number
              p_ppt_path: string
              p_team_lead_name: string
              p_team_lead_phone: string
              p_team_name: string
              p_track_id: string
              p_track_name: string
            }
            Returns: string
          }
    }
    Enums: {
      app_role: "admin" | "editor" | "user"
      registration_status:
        | "REGISTERED"
        | "SHORTLISTED"
        | "SELECTED"
        | "REJECTED"
        | "COMPLETED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "editor", "user"],
      registration_status: [
        "REGISTERED",
        "SHORTLISTED",
        "SELECTED",
        "REJECTED",
        "COMPLETED",
      ],
    },
  },
} as const
