import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { Button, Field, Input } from "@/components/ui/kit";
import { supabase } from "@/integrations/supabase/client";
import { bootstrapAdmin } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/login")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin Sign In | Innovators Fest 2026" },
      { name: "description", content: "Administrator sign-in for the Innovators Fest 2026 event platform." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Admin Sign In | Innovators Fest 2026" },
      { property: "og:description", content: "Administrator access to the Innovators Fest 2026 content system." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminLogin,
});

function AdminLogin() {
  const navigate = useNavigate();
  const setup = useServerFn(bootstrapAdmin);
  const [mode, setMode] = useState<"login" | "setup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => {
      if (data.user) void navigate({ to: "/admin/dashboard", replace: true });
    });
  }, [navigate]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setBusy(true);
    try {
      if (mode === "setup") {
        await setup({ data: { email, password } });
        setInfo("Administrator account is ready. Signing you in...");
      }
      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      if (signInError) throw new Error(signInError.message);
      await navigate({ to: "/admin/dashboard", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center px-5 py-16">
      <div className="grid-bg fixed inset-0 -z-10 opacity-40" aria-hidden="true" />
      <div className="panel w-full max-w-md p-8">
        <div className="grid h-11 w-11 place-items-center rounded-md border border-border bg-surface-2 text-primary">
          <ShieldCheck size={20} />
        </div>
        <h1 className="mt-6 font-display text-2xl font-semibold">ADMIN ACCESS</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {mode === "login"
            ? "Sign in to manage Innovators Fest 2026."
            : "First-time setup for the authorized administrator email."}
        </p>

        <form onSubmit={onSubmit} className="mt-7 space-y-4">
          <Field label="Email" htmlFor="email">
            <Input
              id="email"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          <Field label="Password" htmlFor="password">
            <Input
              id="password"
              type="password"
              autoComplete={mode === "setup" ? "new-password" : "current-password"}
              required
              minLength={10}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          {error && <p className="text-sm text-destructive">{error}</p>}
          {info && <p className="text-sm text-success">{info}</p>}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy && <Loader2 size={16} className="animate-spin" />}
            {mode === "login" ? "SIGN IN" : "CREATE ADMIN & SIGN IN"}
          </Button>
        </form>

        <button
          type="button"
          onClick={() => setMode(mode === "login" ? "setup" : "login")}
          className="mt-5 font-mono text-[0.66rem] tracking-[0.18em] text-muted-foreground hover:text-foreground"
        >
          {mode === "login" ? "FIRST TIME? SET UP ADMIN ACCOUNT" : "BACK TO SIGN IN"}
        </button>

        <div className="mt-6 border-t border-border pt-5">
          <Link
            to="/"
            className="font-mono text-[0.66rem] tracking-[0.18em] text-muted-foreground hover:text-foreground"
          >
            ← BACK TO SITE
          </Link>
        </div>
      </div>
    </div>
  );
}
