import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CollectionEditor, type FieldDef } from "@/components/admin/CollectionEditor";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/_panel/sponsors")({
  component: SponsorsAdmin,
});

function SponsorsAdmin() {
  const tiers = useQuery({
    queryKey: ["sponsor_tiers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sponsor_tiers")
        .select("id, name")
        .order("display_order");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  const sponsorFields: FieldDef[] = [
    { name: "name", label: "Sponsor name" },
    {
      name: "tier_id",
      label: "Tier",
      type: "select",
      options: (tiers.data ?? []).map((t) => ({ value: t.id, label: t.name })),
    },
    { name: "website_url", label: "Website URL" },
    { name: "logo_url", label: "Logo", type: "image", bucket: "sponsor-logos" },
    { name: "description", label: "Description", type: "textarea" },
    { name: "active", label: "Visible", type: "boolean" },
  ];

  return (
    <div className="space-y-12">
      <CollectionEditor
        title="Sponsor tiers"
        description="Tier labels such as Title Sponsor, Gold, Community Partner."
        table="sponsor_tiers"
        defaults={{ name: "", active: true }}
        fields={[
          { name: "name", label: "Tier name" },
          { name: "active", label: "Visible", type: "boolean" },
        ]}
      />
      <CollectionEditor
        title="Sponsors"
        description="Logos are stored privately and served through secure links."
        table="sponsors"
        defaults={{
          name: "",
          description: "",
          website_url: "",
          tier_id: null,
          logo_url: null,
          active: true,
        }}
        fields={sponsorFields}
      />
    </div>
  );
}
