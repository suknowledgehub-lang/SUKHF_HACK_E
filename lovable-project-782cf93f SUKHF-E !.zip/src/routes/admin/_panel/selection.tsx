import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button, Input, Select, Toggle } from "@/components/ui/kit";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/_panel/selection")({
  component: TeamSelectionAdmin,
});

function TeamSelectionAdmin() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");
  const [draft, setDraft] = useState<Record<string, boolean>>({});
  const [message, setMessage] = useState<string | null>(null);

  const rows = useQuery({
    queryKey: ["registrations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("registrations")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!rows.data) return;
    setDraft(Object.fromEntries(rows.data.map((r) => [r.id, r.selected])));
  }, [rows.data]);

  const save = useMutation({
    mutationFn: async () => {
      const changed = (rows.data ?? []).filter((r) => draft[r.id] !== undefined && draft[r.id] !== r.selected);
      for (const r of changed) {
        const { error } = await supabase
          .from("registrations")
          .update({ selected: !!draft[r.id] })
          .eq("id", r.id);
        if (error) throw new Error(error.message);
      }
      return changed.length;
    },
    onSuccess: (count) => {
      setMessage(count ? `Selection updated for ${count} team(s).` : "No changes to save.");
      void qc.invalidateQueries({ queryKey: ["registrations"] });
    },
    onError: (e: Error) => setMessage(e.message),
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (rows.data ?? []).filter((r) => {
      if (filter === "selected" && !draft[r.id]) return false;
      if (filter === "not_selected" && draft[r.id]) return false;
      if (!q) return true;
      return [r.registration_code, r.team_name, r.college_name]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [rows.data, search, filter, draft]);

  const selectedCount = (rows.data ?? []).filter((r) => draft[r.id]).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Team Selection</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {selectedCount} of {rows.data?.length ?? 0} teams marked as selected
          </p>
        </div>
        <div className="flex items-center gap-3">
          {message && <span className="text-sm text-muted-foreground">{message}</span>}
          <Button size="sm" disabled={save.isPending} onClick={() => save.mutate()}>
            {save.isPending && <Loader2 size={14} className="animate-spin" />} SAVE SELECTION
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <Input
          className="max-w-xs"
          placeholder="Search team ID, name or college"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Select className="max-w-45" value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="">All teams</option>
          <option value="selected">Selected</option>
          <option value="not_selected">Not selected</option>
        </Select>
      </div>

      <div className="space-y-2">
        {rows.isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {!rows.isLoading && filtered.length === 0 && (
          <p className="text-sm text-muted-foreground">No teams found.</p>
        )}
        {filtered.map((r) => (
          <div key={r.id} className="panel flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="min-w-0">
              <p className="font-mono text-[0.62rem] tracking-[0.18em] text-primary">
                {r.registration_code}
              </p>
              <p className="mt-1 font-medium">{r.team_name}</p>
              <p className="text-sm text-muted-foreground">{r.college_name}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-[0.62rem] tracking-[0.16em] text-muted-foreground">
                {draft[r.id] ? "SELECTED" : "NOT SELECTED"}
              </span>
              <Toggle
                label={`Selection status for ${r.team_name}`}
                checked={!!draft[r.id]}
                onChange={(v) => setDraft((d) => ({ ...d, [r.id]: v }))}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
