import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/_panel/dashboard")({
  component: Dashboard,
});

const count = async (table: "registrations" | "tracks" | "sponsors" | "winners") => {
  const { count: c, error } = await supabase.from(table).select("id", { count: "exact", head: true });
  if (error) throw new Error(error.message);
  return c ?? 0;
};

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="panel p-5">
      <p className="font-mono text-[0.62rem] tracking-[0.18em] text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-3xl font-semibold">{value}</p>
    </div>
  );
}

function Dashboard() {
  const stats = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => ({
      registrations: await count("registrations"),
      tracks: await count("tracks"),
      sponsors: await count("sponsors"),
      winners: await count("winners"),
    }),
  });

  const settings = useQuery({
    queryKey: ["event_settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("event_settings").select("*").limit(1).single();
      if (error) throw new Error(error.message);
      return data;
    },
  });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold">Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage every part of the Innovators Fest 2026 site from here.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="REGISTERED TEAMS" value={stats.data?.registrations ?? "—"} />
        <Stat label="TRACKS" value={stats.data?.tracks ?? "—"} />
        <Stat label="SPONSORS" value={stats.data?.sponsors ?? "—"} />
        <Stat label="WINNERS" value={stats.data?.winners ?? "—"} />
      </div>

      <div className="panel p-5">
        <p className="font-mono text-[0.62rem] tracking-[0.18em] text-muted-foreground">
          REGISTRATION STATUS
        </p>
        <p className="mt-2 text-lg">
          {settings.data
            ? settings.data.registration_open
              ? "Registrations are OPEN"
              : "Registrations are CLOSED"
            : "Loading..."}
        </p>
        <Link
          to="/admin/content"
          className="mt-3 inline-block font-mono text-[0.64rem] tracking-[0.16em] text-primary hover:underline"
        >
          CHANGE IN CONTENT & SETTINGS →
        </Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          { to: "/admin/registrations", title: "Registrations", body: "Review teams, update statuses and download presentations." },
          { to: "/admin/content", title: "Content & settings", body: "Event details, hero, loading screen, sections and contact info." },
          { to: "/admin/catalog", title: "Tracks & schedule", body: "Tracks, timeline, judging, prizes, benefits and FAQs." },
          { to: "/admin/sponsors", title: "Sponsors", body: "Tiers, sponsor cards and logos." },
          { to: "/admin/winners", title: "Winners", body: "Publish results after the event." },
        ].map((c) => (
          <Link key={c.to} to={c.to} className="panel block p-5 transition-colors hover:border-primary/50">
            <p className="font-display font-semibold">{c.title}</p>
            <p className="mt-1 text-sm text-muted-foreground">{c.body}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
