import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CollectionEditor, type FieldDef } from "@/components/admin/CollectionEditor";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin/_panel/catalog")({
  component: Catalog,
});

const TABS = [
  {
    id: "tracks",
    label: "TRACKS",
    table: "tracks",
    title: "Tracks",
    description: "Problem domains teams can choose during registration.",
    defaults: { name: "", description: "", category_label: "", icon: "rocket", active: true },
    fields: [
      { name: "name", label: "Name" },
      { name: "category_label", label: "Category label" },
      { name: "icon", label: "Icon key" },
      { name: "description", label: "Description", type: "textarea" },
      { name: "active", label: "Visible", type: "boolean" },
    ] as FieldDef[],
  },
  {
    id: "schedule",
    label: "SCHEDULE",
    table: "schedule_items",
    title: "Schedule",
    description: "Two-day timeline shown on the site.",
    titleField: "title",
    defaults: {
      title: "",
      description: "",
      day: 1,
      day_label: "DAY 1",
      date_label: "13 OCTOBER 2026",
      time_label: "",
      active: true,
    },
    fields: [
      { name: "title", label: "Title" },
      { name: "time_label", label: "Time" },
      { name: "day", label: "Day number", type: "number" },
      { name: "day_label", label: "Day label" },
      { name: "date_label", label: "Date label" },
      { name: "description", label: "Description", type: "textarea" },
      { name: "active", label: "Visible", type: "boolean" },
    ] as FieldDef[],
  },
  {
    id: "judging",
    label: "JUDGING",
    table: "judging_criteria",
    title: "Judging criteria",
    titleField: "title",
    defaults: { title: "", description: "", active: true },
    fields: [
      { name: "title", label: "Criterion" },
      { name: "description", label: "Description", type: "textarea" },
      { name: "active", label: "Visible", type: "boolean" },
    ] as FieldDef[],
  },
  {
    id: "prizes",
    label: "PRIZES",
    table: "prizes",
    title: "Prizes",
    titleField: "title",
    defaults: { title: "", position_label: "", amount_label: "", description: "", active: true },
    fields: [
      { name: "position_label", label: "Position label" },
      { name: "title", label: "Title" },
      { name: "amount_label", label: "Amount / reward" },
      { name: "description", label: "Description", type: "textarea" },
      { name: "active", label: "Visible", type: "boolean" },
    ] as FieldDef[],
  },
  {
    id: "benefits",
    label: "BENEFITS",
    table: "benefits",
    title: "Startup benefits",
    titleField: "title",
    defaults: { title: "", description: "", icon: "sparkles", active: true },
    fields: [
      { name: "title", label: "Title" },
      { name: "icon", label: "Icon key" },
      { name: "description", label: "Description", type: "textarea" },
      { name: "active", label: "Visible", type: "boolean" },
    ] as FieldDef[],
  },
  {
    id: "faqs",
    label: "FAQS",
    table: "faqs",
    title: "FAQs",
    titleField: "question",
    defaults: { question: "", answer: "", active: true },
    fields: [
      { name: "question", label: "Question", full: true },
      { name: "answer", label: "Answer", type: "textarea" },
      { name: "active", label: "Visible", type: "boolean" },
    ] as FieldDef[],
  },
] as const;

function Catalog() {
  const [tab, setTab] = useState<string>(TABS[0].id);
  const active = TABS.find((t) => t.id === tab) ?? TABS[0];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "rounded-md px-3 py-2 font-mono text-[0.64rem] tracking-[0.16em] transition-colors",
              t.id === tab
                ? "bg-surface-2 text-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      <CollectionEditor
        key={active.id}
        title={active.title}
        {...("description" in active ? { description: active.description as string } : {})}
        table={active.table}
        fields={active.fields as FieldDef[]}
        defaults={{ ...active.defaults }}
        titleField={"titleField" in active ? (active.titleField as string) : "name"}
      />
    </div>
  );
}
