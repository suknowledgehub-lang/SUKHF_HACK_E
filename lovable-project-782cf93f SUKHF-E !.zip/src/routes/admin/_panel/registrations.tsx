import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Download, FileDown, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { Button, Input, Select } from "@/components/ui/kit";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/_panel/registrations")({
  component: Registrations,
});

const STATUSES = ["REGISTERED", "SHORTLISTED", "SELECTED", "REJECTED", "COMPLETED"] as const;
type Status = (typeof STATUSES)[number];

function Registrations() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string>("");
  const [participation, setParticipation] = useState<string>("");

  const rows = useQuery({
    queryKey: ["registrations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("registrations")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  const setStatusMutation = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: Status }) => {
      const { error } = await supabase.from("registrations").update({ status: value }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["registrations"] }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("registrations").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["registrations"] }),
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (rows.data ?? []).filter((r) => {
      if (status && r.status !== status) return false;
      if (participation && r.participation_type !== participation) return false;
      if (!q) return true;
      return [r.team_name, r.team_lead_name, r.college_name, r.registration_code, r.track_name]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [rows.data, search, status, participation]);

  const downloadPpt = async (path: string | null, name: string | null) => {
    if (!path) return;
    const { data, error } = await supabase.storage.from("ppt-submissions").createSignedUrl(path, 120, {
      download: name ?? true,
    });
    if (error || !data) return;
    window.open(data.signedUrl, "_blank", "noopener");
  };

  const exportCsv = () => {
    const header = [
      "Registration Code",
      "Team Name",
      "Team Lead",
      "Phone",
      "College",
      "Member 2",
      "Member 3",
      "Track",
      "Participation Type",
      "Status",
      "PPT File",
      "Registered At",
    ];
    const lines = filtered.map((r) =>
      [
        r.registration_code,
        r.team_name,
        r.team_lead_name,
        r.team_lead_phone,
        r.college_name,
        r.member2_name,
        r.member3_name,
        r.track_name,
        r.participation_type ?? "",
        r.status,
        r.ppt_file_name ?? "",
        new Date(r.created_at).toISOString(),
      ]
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(","),
    );
    const blob = new Blob([[header.join(","), ...lines].join("\n")], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "innovators-fest-2026-registrations.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Registrations</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered.length} of {rows.data?.length ?? 0} teams
          </p>
        </div>
        <Button size="sm" variant="outline" onClick={exportCsv}>
          <FileDown size={14} /> EXPORT CSV
        </Button>
      </div>

      <div className="flex flex-wrap gap-3">
        <Input
          className="max-w-xs"
          placeholder="Search team, lead, college, code"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Select className="max-w-45" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </Select>
        <Select
          className="max-w-45"
          value={participation}
          onChange={(e) => setParticipation(e.target.value)}
        >
          <option value="">All participation types</option>
          <option value="IDEATION">IDEATION</option>
          <option value="PROTOTYPE">PROTOTYPE</option>
        </Select>
      </div>

      <div className="space-y-3">
        {rows.isLoading && <p className="text-sm text-muted-foreground">Loading...</p>}
        {!rows.isLoading && filtered.length === 0 && (
          <p className="text-sm text-muted-foreground">No registrations yet.</p>
        )}
        {filtered.map((r) => (
          <div key={r.id} className="panel p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="font-mono text-[0.62rem] tracking-[0.18em] text-primary">
                  {r.registration_code}
                </p>
                <p className="mt-1 font-display text-lg font-semibold">{r.team_name}</p>
                <p className="text-sm text-muted-foreground">{r.college_name}</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Select
                  className="h-9 w-40 py-1 text-xs"
                  value={r.status}
                  onChange={(e) =>
                    setStatusMutation.mutate({ id: r.id, value: e.target.value as Status })
                  }
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </Select>
                {r.ppt_path && (
                  <Button
                    size="sm"
                    variant="subtle"
                    onClick={() => void downloadPpt(r.ppt_path, r.ppt_file_name)}
                  >
                    <Download size={14} /> PPT
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  aria-label="Delete registration"
                  onClick={() => {
                    if (window.confirm(`Delete registration ${r.registration_code}?`))
                      remove.mutate(r.id);
                  }}
                >
                  <Trash2 size={15} />
                </Button>
              </div>
            </div>
            <dl className="mt-4 grid gap-3 border-t border-border pt-4 text-sm sm:grid-cols-2 lg:grid-cols-5">
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  PARTICIPATION TYPE
                </dt>
                <dd>{r.participation_type ?? "—"}</dd>
              </div>
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  TEAM LEAD
                </dt>
                <dd>
                  {r.team_lead_name} · {r.team_lead_phone}
                </dd>
              </div>
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  MEMBERS
                </dt>
                <dd>
                  {r.member2_name}, {r.member3_name}
                </dd>
              </div>
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  TRACK
                </dt>
                <dd>{r.track_name || "—"}</dd>
              </div>
              <div>
                <dt className="font-mono text-[0.6rem] tracking-[0.16em] text-muted-foreground">
                  SUBMITTED
                </dt>
                <dd>{new Date(r.created_at).toLocaleString()}</dd>
              </div>
            </dl>
          </div>
        ))}
      </div>
    </div>
  );
}
