import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { AlertTriangle, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Button, Field, Input, Textarea, Toggle } from "@/components/ui/kit";
import { useSignedImage } from "@/hooks/useSignedImage";
import { supabase } from "@/integrations/supabase/client";
import { PARTICIPATION_CONTENT_KEY, participationConfig } from "@/lib/cms";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin/_panel/content")({
  component: ContentAdmin,
  errorComponent: ContentAdminError,
});

const CONTENT_ROWS_QUERY_KEY = ["admin", "site_content", "rows"] as const;
const HERO_QUERY_KEY = ["admin", "site_content", "hero"] as const;

function ContentAdminError({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();

  return (
    <div className="panel mx-auto max-w-xl p-8 text-center" role="alert">
      <AlertTriangle className="mx-auto text-destructive" />
      <h1 className="mt-4 font-display text-xl font-semibold">Content & Settings could not load</h1>
      <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
      <Button
        className="mt-6"
        onClick={() => {
          reset();
          void router.invalidate();
        }}
      >
        TRY AGAIN
      </Button>
    </div>
  );
}

type Settings = Record<string, unknown> & { id: string };

function AssetField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string | null;
  onChange: (path: string | null) => void;
}) {
  const url = useSignedImage(value, "site-assets");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <Field label={label}>
      <div className="space-y-2">
        {url && (
          <img
            src={url}
            alt={`${label} preview`}
            className="h-16 w-auto rounded border border-border bg-background object-contain p-2"
          />
        )}
        <div className="flex items-center gap-2">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border-strong px-3 py-2 text-xs hover:border-primary/60">
            {busy && <Loader2 size={14} className="animate-spin" />}
            {value ? "REPLACE" : "UPLOAD"}
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                setError(null);
                setBusy(true);
                const uploadId = crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
                const path = `${uploadId}/${file.name.replace(/[^\w.\- ]+/g, "_")}`;
                const { error } = await supabase.storage
                  .from("site-assets")
                  .upload(path, file, file.type ? { contentType: file.type } : {});
                setBusy(false);
                if (error) {
                  setError(error.message);
                  return;
                }
                onChange(path);
              }}
            />
          </label>
          {value && (
            <Button type="button" size="sm" variant="ghost" onClick={() => onChange(null)}>
              REMOVE
            </Button>
          )}
        </div>
        {error && <p className="text-xs text-destructive">Upload failed: {error}</p>}
      </div>
    </Field>
  );
}

const TEXT_FIELDS: Array<{ name: string; label: string; type?: "textarea" | "datetime" }> = [
  { name: "event_name", label: "Event name" },
  { name: "event_year", label: "Event year" },
  { name: "tagline", label: "Tagline" },
  { name: "organizer", label: "Organizer" },
  { name: "venue", label: "Venue" },
  { name: "city", label: "City" },
  { name: "address", label: "Address" },
  { name: "date_label", label: "Date label" },
  { name: "duration_label", label: "Duration label" },
  { name: "contact_email", label: "Contact email" },
  { name: "contact_phone", label: "Contact phone" },
  { name: "registration_button_text", label: "Registration button text" },
  { name: "loading_text", label: "Loading screen text" },
  { name: "description", label: "Event description", type: "textarea" },
];

const DATE_FIELDS = [
  { name: "start_date", label: "Start date & time" },
  { name: "end_date", label: "End date & time" },
  { name: "registration_close_date", label: "Registration closes (optional)" },
];

const toLocalInput = (v: unknown) => {
  if (!v) return "";
  const d = new Date(String(v));
  if (Number.isNaN(d.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

function SettingsPanel() {
  const qc = useQueryClient();
  const [draft, setDraft] = useState<Settings | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const query = useQuery({
    queryKey: ["event_settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("event_settings")
        .select("*")
        .limit(1)
        .maybeSingle();
      if (error) throw new Error(error.message);
      if (!data) throw new Error("Event settings are missing. Please try again.");
      return data as unknown as Settings;
    },
  });

  useEffect(() => {
    if (query.data) setDraft(query.data);
  }, [query.data]);

  const save = useMutation({
    mutationFn: async (payload: Settings) => {
      const { id, ...rest } = payload;
      const { error } = await supabase
        .from("event_settings")
        .update(rest as never)
        .eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setMessage("Settings saved successfully.");
      void qc.invalidateQueries({ queryKey: ["event_settings"] });
    },
    onError: (e: Error) => setMessage(`Could not save: ${e.message}`),
  });

  if (query.isError) {
    return (
      <div className="panel p-5">
        <p className="text-sm text-destructive">Event settings could not be loaded.</p>
        <Button className="mt-4" size="sm" variant="outline" onClick={() => void query.refetch()}>
          TRY AGAIN
        </Button>
      </div>
    );
  }

  if (!draft) {
    return (
      <div className="panel flex items-center gap-3 p-5 text-sm text-muted-foreground">
        <Loader2 size={16} className="animate-spin text-primary" /> Loading event settings…
      </div>
    );
  }

  const set = (k: string, v: unknown) => setDraft({ ...draft, [k]: v });

  return (
    <section className="space-y-5">
      <div>
        <h2 className="font-display text-xl font-semibold">Event details & settings</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Controls the hero, countdown, footer, loading screen and registration availability.
        </p>
      </div>

      <div className="panel grid gap-4 p-5 sm:grid-cols-2">
        {TEXT_FIELDS.map((f) => (
          <div key={f.name} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
            <Field label={f.label}>
              {f.type === "textarea" ? (
                <Textarea
                  value={String(draft[f.name] ?? "")}
                  onChange={(e) => set(f.name, e.target.value)}
                />
              ) : (
                <Input
                  value={String(draft[f.name] ?? "")}
                  onChange={(e) => set(f.name, e.target.value)}
                />
              )}
            </Field>
          </div>
        ))}

        {DATE_FIELDS.map((f) => (
          <Field key={f.name} label={f.label}>
            <Input
              type="datetime-local"
              value={toLocalInput(draft[f.name])}
              onChange={(e) =>
                set(f.name, e.target.value ? new Date(e.target.value).toISOString() : null)
              }
            />
          </Field>
        ))}

        <AssetField
          label="Organizer logo"
          value={(draft["organizer_logo_url"] as string) ?? null}
          onChange={(p) => set("organizer_logo_url", p)}
        />
        <AssetField
          label="Loading screen logo"
          value={(draft["loading_logo_url"] as string) ?? null}
          onChange={(p) => set("loading_logo_url", p)}
        />

        <div className="flex items-center gap-3 sm:col-span-2">
          <Toggle
            label="Registrations open"
            checked={!!draft["registration_open"]}
            onChange={(v) => set("registration_open", v)}
          />
          <span className="text-sm">Registrations open</span>
        </div>
        <div className="flex items-center gap-3 sm:col-span-2">
          <Toggle
            label="Loading screen enabled"
            checked={!!draft["loading_enabled"]}
            onChange={(v) => set("loading_enabled", v)}
          />
          <span className="text-sm">Show loading screen</span>
        </div>

        <div className="flex items-center gap-3 sm:col-span-2">
          <Button disabled={save.isPending} onClick={() => save.mutate(draft)}>
            {save.isPending && <Loader2 size={14} className="animate-spin" />} SAVE SETTINGS
          </Button>
          {message && <span className="text-sm text-muted-foreground">{message}</span>}
        </div>
      </div>
    </section>
  );
}

function ContentBlocks() {
  const qc = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState<Record<string, string>>({});

  const query = useQuery({
    queryKey: CONTENT_ROWS_QUERY_KEY,
    queryFn: async () => {
      const { data, error } = await supabase.from("site_content").select("*").order("key");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  const save = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: unknown }) => {
      const { error } = await supabase
        .from("site_content")
        .upsert({ key, value: value as never }, { onConflict: "key" });
      if (error) throw new Error(error.message);
      return key;
    },
    onSuccess: (key) => {
      setSaved((s) => ({ ...s, [key]: "Saved successfully." }));
      setErrors((e) => ({ ...e, [key]: "" }));
      void qc.invalidateQueries({ queryKey: ["site_content"] });
      void qc.invalidateQueries({ queryKey: CONTENT_ROWS_QUERY_KEY });
    },
    onError: (e: Error, vars) => {
      setSaved((s) => ({ ...s, [vars.key]: "" }));
      setErrors((er) => ({ ...er, [vars.key]: `Could not save: ${e.message}` }));
    },
  });

  if (query.isError) {
    return (
      <div className="panel p-5">
        <p className="text-sm text-destructive">Section content could not be loaded.</p>
        <Button className="mt-4" size="sm" variant="outline" onClick={() => void query.refetch()}>
          TRY AGAIN
        </Button>
      </div>
    );
  }

  return (
    <section className="space-y-5">
      <div>
        <h2 className="font-display text-xl font-semibold">Section content</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Headings and copy for the hero, about, format, how it works, judging, prizes,
          certificates, footer and other blocks.
        </p>
      </div>

      {query.isPending && (
        <div className="panel flex items-center gap-3 p-5 text-sm text-muted-foreground">
          <Loader2 size={16} className="animate-spin text-primary" /> Loading section content…
        </div>
      )}

      {(query.data ?? []).map((row) => {
        const key = row.key;
        const text = drafts[key] ?? JSON.stringify(row.value, null, 2);
        return (
          <div key={key} className="panel space-y-3 p-5">
            <p className="font-mono text-[0.64rem] uppercase tracking-[0.18em] text-primary">
              {key.replace(/_/g, " ")}
            </p>
            <Textarea
              className={cn("min-h-56 font-mono text-xs", errors[key] && "border-destructive")}
              value={text}
              onChange={(e) => setDrafts((d) => ({ ...d, [key]: e.target.value }))}
            />
            {errors[key] && <p className="text-xs text-destructive">{errors[key]}</p>}
            <div className="flex items-center gap-3">
              <Button
                size="sm"
                onClick={() => {
                  try {
                    const parsed = JSON.parse(text) as unknown;
                    setErrors((e) => ({ ...e, [key]: "" }));
                    setSaved((s) => ({ ...s, [key]: "" }));
                    save.mutate({ key, value: parsed });
                  } catch {
                    setSaved((s) => ({ ...s, [key]: "" }));
                    setErrors((e) => ({
                      ...e,
                      [key]: "Please check the formatting and try again.",
                    }));
                  }
                }}
              >
                SAVE BLOCK
              </Button>
              {saved[key] && <span className="text-xs text-muted-foreground">{saved[key]}</span>}
            </div>
          </div>
        );
      })}
    </section>
  );
}

const HERO_FIELDS = [
  { name: "label", label: "Event label", placeholder: "NATIONAL HACKATHON · HYDERABAD" },
  { name: "title_line1", label: "Main event name", placeholder: "INNOVATORS" },
  { name: "title_line2", label: "Event name second line", placeholder: "FEST 2026" },
  { name: "tagline", label: "Tagline", placeholder: "BUILD. PITCH. LAUNCH." },
] as const;

function HeroContentPanel() {
  const qc = useQueryClient();
  const [draft, setDraft] = useState<Record<string, unknown> | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const query = useQuery({
    queryKey: HERO_QUERY_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_content")
        .select("*")
        .eq("key", "hero")
        .maybeSingle();
      if (error) throw new Error(error.message);
      return (data?.value ?? {}) as Record<string, unknown>;
    },
  });

  useEffect(() => {
    if (!query.data) return;
    const value = query.data;
    const headline = typeof value["headline"] === "string" ? (value["headline"] as string) : "";
    const match = headline.match(/^(.*?)(FEST\s+\d{4})$/i);
    setDraft({
      ...value,
      label: value["label"] ?? "",
      title_line1: value["title_line1"] ?? (match?.[1]?.trim() || headline),
      title_line2: value["title_line2"] ?? (match?.[2]?.trim() || ""),
      tagline: value["tagline"] ?? "",
    });
  }, [query.data]);

  const save = useMutation({
    mutationFn: async (value: Record<string, unknown>) => {
      const line1 = String(value["title_line1"] ?? "").trim();
      const line2 = String(value["title_line2"] ?? "").trim();
      const merged = {
        ...(query.data ?? {}),
        ...value,
        headline: [line1, line2].filter(Boolean).join(" ") || value["headline"] || "",
      };
      const { error } = await supabase
        .from("site_content")
        .upsert({ key: "hero", value: merged as never }, { onConflict: "key" });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setMessage("Hero content updated successfully.");
      void qc.invalidateQueries({ queryKey: ["site_content"] });
      void qc.invalidateQueries({ queryKey: HERO_QUERY_KEY });
      void qc.invalidateQueries({ queryKey: CONTENT_ROWS_QUERY_KEY });
    },
    onError: (e: Error) => setMessage(e.message),
  });

  if (query.isError) {
    return (
      <div className="panel p-5">
        <p className="text-sm text-destructive">Homepage content could not be loaded.</p>
        <Button className="mt-4" size="sm" variant="outline" onClick={() => void query.refetch()}>
          TRY AGAIN
        </Button>
      </div>
    );
  }

  if (!draft) {
    return (
      <div className="panel flex items-center gap-3 p-5 text-sm text-muted-foreground">
        <Loader2 size={16} className="animate-spin text-primary" /> Loading homepage content…
      </div>
    );
  }

  return (
    <section className="space-y-5">
      <div>
        <h2 className="font-display text-xl font-semibold">Event / Hero content</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          The event label, event name and tagline shown at the top of the homepage.
        </p>
      </div>
      <div className="panel grid gap-4 p-5 sm:grid-cols-2">
        {HERO_FIELDS.map((f) => (
          <Field key={f.name} label={f.label}>
            <Input
              placeholder={f.placeholder}
              value={String(draft[f.name] ?? "")}
              onChange={(e) => setDraft({ ...draft, [f.name]: e.target.value })}
            />
          </Field>
        ))}
        <div className="flex items-center gap-3 sm:col-span-2">
          <Button disabled={save.isPending} onClick={() => save.mutate(draft)}>
            {save.isPending && <Loader2 size={14} className="animate-spin" />} SAVE HERO CONTENT
          </Button>
          {message && <span className="text-sm text-muted-foreground">{message}</span>}
        </div>
      </div>
    </section>
  );
}

const PARTICIPATION_QUERY_KEY = ["admin", "site_content", PARTICIPATION_CONTENT_KEY] as const;

const PARTICIPATION_FIELDS = [
  { name: "heading", label: "Section title", type: "input" },
  { name: "subheading", label: "Section subtitle", type: "textarea" },
  { name: "ideation_title", label: "IDEATION title", type: "input" },
  { name: "ideation_description", label: "IDEATION description", type: "textarea" },
  { name: "prototype_title", label: "PROTOTYPE title", type: "input" },
  { name: "prototype_description", label: "PROTOTYPE description", type: "textarea" },
] as const;

function ParticipationPanel() {
  const qc = useQueryClient();
  const [draft, setDraft] = useState<Record<string, unknown> | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const query = useQuery({
    queryKey: PARTICIPATION_QUERY_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_content")
        .select("value")
        .eq("key", PARTICIPATION_CONTENT_KEY)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return (data?.value ?? {}) as Record<string, unknown>;
    },
  });

  useEffect(() => {
    if (!query.data) return;
    const cfg = participationConfig(query.data);
    setDraft({
      ...query.data,
      enabled: cfg.enabled,
      heading: cfg.heading,
      subheading: cfg.subheading,
      ideation_title: cfg.ideationTitle,
      ideation_description: cfg.ideationDescription,
      prototype_title: cfg.prototypeTitle,
      prototype_description: cfg.prototypeDescription,
      ideation_registration_enabled: cfg.ideationRegistrationEnabled,
      prototype_registration_enabled: cfg.prototypeRegistrationEnabled,
    });
  }, [query.data]);

  const save = useMutation({
    mutationFn: async (value: Record<string, unknown>) => {
      const { error } = await supabase
        .from("site_content")
        .upsert(
          { key: PARTICIPATION_CONTENT_KEY, value: value as never },
          { onConflict: "key" },
        );
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setMessage("Saved successfully.");
      void qc.invalidateQueries({ queryKey: ["site_content"] });
      void qc.invalidateQueries({ queryKey: PARTICIPATION_QUERY_KEY });
      void qc.invalidateQueries({ queryKey: CONTENT_ROWS_QUERY_KEY });
    },
    onError: (e: Error) => setMessage(`Could not save: ${e.message}`),
  });

  if (query.isError) {
    return (
      <div className="panel p-5">
        <p className="text-sm text-destructive">Ideation or Prototype settings could not load.</p>
        <Button className="mt-4" size="sm" variant="outline" onClick={() => void query.refetch()}>
          TRY AGAIN
        </Button>
      </div>
    );
  }

  if (!draft) {
    return (
      <div className="panel flex items-center gap-3 p-5 text-sm text-muted-foreground">
        <Loader2 size={16} className="animate-spin text-primary" /> Loading Ideation or Prototype…
      </div>
    );
  }

  const set = (k: string, v: unknown) => setDraft({ ...draft, [k]: v });

  return (
    <section className="space-y-5">
      <div>
        <h2 className="font-display text-xl font-semibold">Ideation or Prototype</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          The homepage section and the participation options students can choose during
          registration.
        </p>
      </div>
      <div className="panel grid gap-4 p-5 sm:grid-cols-2">
        {PARTICIPATION_FIELDS.map((f) => (
          <div key={f.name} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
            <Field label={f.label}>
              {f.type === "textarea" ? (
                <Textarea
                  value={String(draft[f.name] ?? "")}
                  onChange={(e) => set(f.name, e.target.value)}
                />
              ) : (
                <Input
                  value={String(draft[f.name] ?? "")}
                  onChange={(e) => set(f.name, e.target.value)}
                />
              )}
            </Field>
          </div>
        ))}

        {[
          { key: "enabled", label: "Show the section on the homepage" },
          { key: "ideation_registration_enabled", label: "IDEATION available in registration" },
          { key: "prototype_registration_enabled", label: "PROTOTYPE available in registration" },
        ].map((t) => (
          <div key={t.key} className="flex items-center gap-3 sm:col-span-2">
            <Toggle
              label={t.label}
              checked={!!draft[t.key]}
              onChange={(v) => set(t.key, v)}
            />
            <span className="text-sm">{t.label}</span>
          </div>
        ))}

        <div className="flex items-center gap-3 sm:col-span-2">
          <Button disabled={save.isPending} onClick={() => save.mutate(draft)}>
            {save.isPending && <Loader2 size={14} className="animate-spin" />} SAVE SECTION
          </Button>
          {message && <span className="text-sm text-muted-foreground">{message}</span>}
        </div>
      </div>
    </section>
  );
}

function ContentAdmin() {
  return (
    <div className="space-y-12">
      <HeroContentPanel />
      <ParticipationPanel />
      <SettingsPanel />
      <ContentBlocks />
    </div>
  );
}
