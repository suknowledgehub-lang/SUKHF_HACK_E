import { createFileRoute } from "@tanstack/react-router";
import { CollectionEditor } from "@/components/admin/CollectionEditor";

export const Route = createFileRoute("/admin/_panel/winners")({
  component: Winners,
});

function Winners() {
  return (
    <CollectionEditor
      title="Winners"
      description="Published winners appear on the public site. Keep them unpublished until results are announced."
      table="winners"
      orderBy="position"
      titleField="team_name"
      defaults={{
        team_name: "",
        project_name: "",
        college: "",
        members: "",
        track: "",
        prize: "",
        position: 1,
        published: false,
        image_url: null,
      }}
      fields={[
        { name: "position", label: "Position", type: "number" },
        { name: "team_name", label: "Team name" },
        { name: "project_name", label: "Project name" },
        { name: "college", label: "College" },
        { name: "track", label: "Track" },
        { name: "prize", label: "Prize" },
        { name: "members", label: "Members", type: "textarea" },
        { name: "image_url", label: "Photo", type: "image", bucket: "site-assets" },
        { name: "published", label: "Published", type: "boolean" },
      ]}
    />
  );
}
