import { useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { Loader2, LogOut, ShieldAlert } from "lucide-react";
import { useEffect } from "react";
import { Button } from "@/components/ui/kit";
import { useAdmin } from "@/hooks/useAdmin";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin/_panel")({
  ssr: false,
  component: AdminPanel,
});

const NAV = [
  { to: "/admin/dashboard", label: "DASHBOARD" },
  { to: "/admin/registrations", label: "REGISTRATIONS" },
  { to: "/admin/selection", label: "TEAM SELECTION" },
  { to: "/admin/content", label: "CONTENT & SETTINGS" },
  { to: "/admin/catalog", label: "TRACKS & SCHEDULE" },
  { to: "/admin/sponsors", label: "SPONSORS" },
  { to: "/admin/winners", label: "WINNERS" },
] as const;

function AdminPanel() {
  const { loading, isAdmin, email } = useAdmin();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (!loading && !email) void navigate({ to: "/admin/login", replace: true });
  }, [loading, email, navigate]);

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    await navigate({ to: "/admin/login", replace: true });
  };

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="grid min-h-screen place-items-center px-5">
        <div className="panel max-w-md p-8 text-center">
          <ShieldAlert className="mx-auto text-destructive" />
          <h1 className="mt-4 font-display text-xl font-semibold">No administrator access</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            This account is signed in but does not have administrator permissions.
          </p>
          <Button className="mt-6" variant="outline" onClick={signOut}>
            SIGN OUT
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-5 py-3">
          <div>
            <p className="font-display text-sm font-semibold tracking-wide">
              INNOVATORS FEST 2026 · ADMIN
            </p>
            <p className="font-mono text-[0.62rem] tracking-[0.16em] text-muted-foreground">
              {email}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/" className="text-xs text-muted-foreground hover:text-foreground">
              View site
            </Link>
            <Button size="sm" variant="ghost" onClick={signOut}>
              <LogOut size={14} /> SIGN OUT
            </Button>
          </div>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-3 pb-2">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "whitespace-nowrap rounded-md px-3 py-2 font-mono text-[0.64rem] tracking-[0.16em] transition-colors",
                pathname === item.to
                  ? "bg-surface-2 text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-5 py-8">
        <Outlet />
      </main>
    </div>
  );
}
