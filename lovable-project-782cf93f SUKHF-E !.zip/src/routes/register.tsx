import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Check, FileUp, Loader2, Trash2 } from "lucide-react";
import { useRef, useState } from "react";
import { z } from "zod";
import { Button, Field, Input, Select } from "@/components/ui/kit";
import { supabase } from "@/integrations/supabase/client";
import {
  participationConfig,
  participationQuery,
  settingsQuery,
  tracksQuery,
  type ParticipationType,
} from "@/lib/cms";
import { syncRegistrationToSheet } from "@/lib/sheets.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/register")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Register Your Team | Innovators Fest 2026" },
      {
        name: "description",
        content:
          "Register a team of three for Innovators Fest 2026, the 35-hour hackathon at MJCET Hyderabad. Pick a track and upload your project presentation.",
      },
      { property: "og:title", content: "Register Your Team | Innovators Fest 2026" },
      {
        property: "og:description",
        content:
          "Team registration for the 35-hour Innovators Fest 2026 hackathon: 1 Team Lead and 2 Team Members.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RegisterPage,
});

const STEPS = [
  "PARTICIPATION",
  "TEAM",
  "MEMBERS",
  "TRACK",
  "PRESENTATION",
  "REVIEW",
  "SUBMIT",
];
const LAST_STEP = STEPS.length - 1;

const schema = z.object({
  team_name: z.string().trim().min(2, "Team name is required").max(80),
  team_lead_name: z.string().trim().min(2, "Team lead name is required").max(80),
  team_lead_phone: z
    .string()
    .trim()
    .regex(/^(\+91[- ]?)?[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number"),
  college_name: z.string().trim().min(2, "College name is required").max(120),
  member2_name: z.string().trim().min(2, "Team member 2 is required").max(80),
  member3_name: z.string().trim().min(2, "Team member 3 is required").max(80),
  track_id: z.string().uuid("Select a track"),
});

type Form = z.infer<typeof schema>;

const EMPTY: Form = {
  team_name: "",
  team_lead_name: "",
  team_lead_phone: "",
  college_name: "",
  member2_name: "",
  member3_name: "",
  track_id: "",
};

function RegisterPage() {
  const settings = useQuery(settingsQuery);
  const tracks = useQuery(tracksQuery);
  const participation = useQuery(participationQuery);
  const [step, setStep] = useState(0);
  const [participationType, setParticipationType] = useState<ParticipationType | "">("");
  const [participationError, setParticipationError] = useState<string | null>(null);
  const [form, setForm] = useState<Form>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof Form, string>>>({});
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploaded, setUploaded] = useState<{ path: string; name: string; size: number } | null>(
    null,
  );
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [result, setResult] = useState<{ code: string; track: string; participation: string } | null>(
    null,
  );
  const inputRef = useRef<HTMLInputElement | null>(null);

  const activeTracks = (tracks.data ?? []).filter((t) => t.active);
  const pcfg = participationConfig(participation.data);
  const participationOptions: Array<{
    value: ParticipationType;
    title: string;
    description: string;
  }> = [
    ...(pcfg.ideationRegistrationEnabled
      ? [
          {
            value: "IDEATION" as ParticipationType,
            title: pcfg.ideationTitle,
            description: pcfg.ideationDescription,
          },
        ]
      : []),
    ...(pcfg.prototypeRegistrationEnabled
      ? [
          {
            value: "PROTOTYPE" as ParticipationType,
            title: pcfg.prototypeTitle,
            description: pcfg.prototypeDescription,
          },
        ]
      : []),
  ];
  const s = settings.data;
  const closed =
    !!s &&
    (!s.registration_open ||
      (s.registration_close_date && new Date(s.registration_close_date) < new Date()));

  const set = (key: keyof Form, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const validateStep = () => {
    const fields: Array<keyof Form>[] = [
      [],
      ["team_name", "team_lead_name", "team_lead_phone", "college_name"],
      ["member2_name", "member3_name"],
      ["track_id"],
      [],
      [],
      [],
    ];
    const keys = fields[step] ?? [];
    const parsed = schema.safeParse(form);
    if (parsed.success) return true;
    const next: Partial<Record<keyof Form, string>> = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path[0] as keyof Form;
      if (keys.includes(key)) next[key] = issue.message;
    }
    if (Object.keys(next).length) {
      setErrors(next);
      return false;
    }
    return true;
  };

  const uploadPpt = async (selected: File) => {
    setUploadError(null);
    const ext = selected.name.split(".").pop()?.toLowerCase();
    if (ext !== "ppt" && ext !== "pptx") {
      setUploadError("Only .ppt and .pptx files are accepted.");
      return;
    }
    if (selected.size > 50 * 1024 * 1024) {
      setUploadError("File must be smaller than 50 MB.");
      return;
    }
    setFile(selected);
    setUploading(true);
    const path = `${crypto.randomUUID()}/${selected.name.replace(/[^\w.\- ]+/g, "_")}`;
    const { error } = await supabase.storage.from("ppt-submissions").upload(path, selected, {
      upsert: false,
      contentType: selected.type || "application/vnd.ms-powerpoint",
    });
    setUploading(false);
    if (error) {
      setUploadError(error.message);
      setFile(null);
      return;
    }
    setUploaded({ path, name: selected.name, size: selected.size });
  };

  const removePpt = async () => {
    if (uploaded) await supabase.storage.from("ppt-submissions").remove([uploaded.path]);
    setUploaded(null);
    setFile(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const submit = useMutation({
    mutationFn: async () => {
      const parsed = schema.parse(form);
      if (!uploaded) throw new Error("Please upload your project presentation.");
      const track = activeTracks.find((t) => t.id === parsed.track_id);
      const { data, error } = await supabase.rpc("submit_registration", {
        p_team_name: parsed.team_name,
        p_team_lead_name: parsed.team_lead_name,
        p_team_lead_phone: parsed.team_lead_phone,
        p_college_name: parsed.college_name,
        p_track_id: parsed.track_id,
        p_track_name: track?.name ?? "",
        p_member2_name: parsed.member2_name,
        p_member3_name: parsed.member3_name,
        p_ppt_file_name: uploaded.name,
        p_ppt_file_size: uploaded.size,
        p_ppt_path: uploaded.path,
        p_participation_type: participationType || null,
      });
      if (error) {
        if (error.code === "23505")
          throw new Error("A registration already exists with this team name or phone number.");
        throw new Error(error.message);
      }
      const code = data as string;
      try {
        await syncRegistrationToSheet({ data: { registration_code: code } });
      } catch (err) {
        console.error("Sheet sync failed", err);
      }
      return { code, track: track?.name ?? "", participation: participationType || "-" };
    },
    onSuccess: (r) => setResult(r),
  });

  if (result) {
    return (
      <Shell>
        <div className="panel mx-auto max-w-2xl p-8">
          <div className="grid h-12 w-12 place-items-center rounded-full bg-primary/15 text-primary">
            <Check size={22} />
          </div>
          <h1 className="mt-6 font-display text-3xl font-semibold">REGISTRATION SUCCESSFUL</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Save your registration ID. You will need it at check-in on 13 October 2026.
          </p>
          <dl className="mt-8 divide-y divide-border border-y border-border text-sm">
            {[
              ["Registration ID", result.code],
              ["Team Name", form.team_name],
              ["Participation Type", result.participation],
              ["Team Lead", `${form.team_lead_name} (${form.team_lead_phone})`],
              ["Members", `${form.member2_name}, ${form.member3_name}`],
              ["College", form.college_name],
              ["Track", result.track],
              ["PPT Submitted", uploaded?.name ?? "-"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-6 py-3">
                <dt className="font-mono text-[0.66rem] tracking-[0.18em] text-muted-foreground">
                  {String(k).toUpperCase()}
                </dt>
                <dd className="text-right text-foreground">{v}</dd>
              </div>
            ))}
          </dl>
          <Link to="/" className="mt-8 inline-block">
            <Button variant="outline">Back to site</Button>
          </Link>
        </div>
      </Shell>
    );
  }

  if (closed) {
    return (
      <Shell>
        <div className="panel mx-auto max-w-xl p-10 text-center">
          <h1 className="font-display text-2xl font-semibold">REGISTRATIONS ARE CLOSED</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Team registration for {s?.event_name} is no longer accepting submissions.
          </p>
          <Link to="/" className="mt-8 inline-block">
            <Button variant="outline">Back to site</Button>
          </Link>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="mx-auto max-w-3xl">
        <p className="eyebrow">TEAM REGISTRATION</p>
        <h1 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
          {s?.event_name ?? "INNOVATORS FEST 2026"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Each team has exactly 3 members: 1 Team Lead and 2 Team Members. The Team Lead pitches on
          Day 2.
        </p>

        <ol className="mt-8 flex flex-wrap gap-2">
          {STEPS.map((label, i) => (
            <li
              key={label}
              className={cn(
                "rounded-md border px-3 py-1.5 font-mono text-[0.6rem] tracking-[0.16em]",
                i === step
                  ? "border-primary/50 bg-primary/10 text-primary"
                  : i < step
                    ? "border-border text-foreground"
                    : "border-border text-muted-foreground/60",
              )}
            >
              {i + 1}. {label}
            </li>
          ))}
        </ol>

        <div className="panel mt-6 p-6 sm:p-8">
          {step === 0 && (
            <div className="space-y-5">
              <div>
                <h2 className="font-display text-lg font-semibold">Choose Your Participation</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Select exactly one participation type to continue.
                </p>
              </div>
              {participationOptions.length === 0 ? (
                <p className="rounded-lg border border-destructive/40 bg-destructive/5 p-4 text-sm text-destructive">
                  Registration options are currently unavailable. Please check back later.
                </p>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2">
                  {participationOptions.map((o) => (
                    <button
                      key={o.value}
                      type="button"
                      aria-pressed={participationType === o.value}
                      onClick={() => {
                        setParticipationType(o.value);
                        setParticipationError(null);
                      }}
                      className={cn(
                        "rounded-lg border p-5 text-left transition-all",
                        participationType === o.value
                          ? "border-primary/60 bg-primary/10 shadow-[0_18px_50px_-30px_var(--ring)]"
                          : "border-border hover:border-border-strong",
                      )}
                    >
                      <span className="flex items-center gap-2">
                        <span
                          className={cn(
                            "grid h-4 w-4 place-items-center rounded-full border",
                            participationType === o.value
                              ? "border-primary bg-primary/20"
                              : "border-border-strong",
                          )}
                        >
                          {participationType === o.value && (
                            <span className="h-2 w-2 rounded-full bg-primary" />
                          )}
                        </span>
                        <span className="font-display font-semibold">{o.title}</span>
                      </span>
                      <span className="mt-2 block text-sm text-muted-foreground">
                        {o.description}
                      </span>
                    </button>
                  ))}
                </div>
              )}
              {participationError && (
                <p className="text-xs text-destructive">{participationError}</p>
              )}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-5">
              <Field label="Team Name" error={errors.team_name} htmlFor="team_name">
                <Input
                  id="team_name"
                  value={form.team_name}
                  maxLength={80}
                  onChange={(e) => set("team_name", e.target.value)}
                />
              </Field>
              <Field label="Team Lead Name" error={errors.team_lead_name} htmlFor="lead">
                <Input
                  id="lead"
                  value={form.team_lead_name}
                  maxLength={80}
                  onChange={(e) => set("team_lead_name", e.target.value)}
                />
              </Field>
              <Field
                label="Team Lead Phone Number"
                error={errors.team_lead_phone}
                hint="10-digit Indian mobile number"
                htmlFor="phone"
              >
                <Input
                  id="phone"
                  inputMode="tel"
                  value={form.team_lead_phone}
                  maxLength={14}
                  onChange={(e) => set("team_lead_phone", e.target.value)}
                />
              </Field>
              <Field label="College Name" error={errors.college_name} htmlFor="college">
                <Input
                  id="college"
                  value={form.college_name}
                  maxLength={120}
                  onChange={(e) => set("college_name", e.target.value)}
                />
              </Field>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              <p className="text-sm text-muted-foreground">
                The Team Lead ({form.team_lead_name || "-"}) counts as member 1.
              </p>
              <Field label="Team Member 2" error={errors.member2_name} htmlFor="m2">
                <Input
                  id="m2"
                  value={form.member2_name}
                  maxLength={80}
                  onChange={(e) => set("member2_name", e.target.value)}
                />
              </Field>
              <Field label="Team Member 3" error={errors.member3_name} htmlFor="m3">
                <Input
                  id="m3"
                  value={form.member3_name}
                  maxLength={80}
                  onChange={(e) => set("member3_name", e.target.value)}
                />
              </Field>
            </div>
          )}

          {step === 3 && (
            <div className="grid gap-3 sm:grid-cols-2">
              {activeTracks.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => set("track_id", t.id)}
                  className={cn(
                    "rounded-lg border p-4 text-left transition-all",
                    form.track_id === t.id
                      ? "border-primary/60 bg-primary/10"
                      : "border-border hover:border-border-strong",
                  )}
                >
                  <p className="eyebrow">{t.category_label}</p>
                  <p className="mt-1 font-display font-semibold">{t.name}</p>
                  <p className="mt-1.5 text-sm text-muted-foreground">{t.description}</p>
                </button>
              ))}
              {errors.track_id && <p className="text-xs text-destructive">{errors.track_id}</p>}
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Upload your project presentation (.ppt or .pptx) directly from your device.
              </p>
              <input
                ref={inputRef}
                type="file"
                accept=".ppt,.pptx"
                className="sr-only"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void uploadPpt(f);
                }}
              />
              {!uploaded && (
                <Button
                  type="button"
                  variant="outline"
                  disabled={uploading}
                  onClick={() => inputRef.current?.click()}
                >
                  {uploading ? <Loader2 size={16} className="animate-spin" /> : <FileUp size={16} />}
                  {uploading ? "UPLOADING..." : "SELECT PPT"}
                </Button>
              )}
              {uploading && (
                <div className="h-1 w-full overflow-hidden rounded bg-surface-2">
                  <div className="h-full w-1/2 animate-pulse bg-primary" />
                </div>
              )}
              {uploaded && (
                <div className="rounded-lg border border-success/40 bg-success/5 p-4">
                  <p className="flex items-center gap-2 text-sm text-success">
                    <Check size={15} /> UPLOADED SUCCESSFULLY
                  </p>
                  <p className="mt-2 text-sm text-foreground">{uploaded.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(uploaded.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                  <div className="mt-3 flex gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="subtle"
                      onClick={() => {
                        void removePpt().then(() => inputRef.current?.click());
                      }}
                    >
                      REPLACE PPT
                    </Button>
                    <Button type="button" size="sm" variant="ghost" onClick={() => void removePpt()}>
                      <Trash2 size={14} /> REMOVE
                    </Button>
                  </div>
                </div>
              )}
              {uploadError && <p className="text-xs text-destructive">{uploadError}</p>}
              {file && !uploaded && !uploading && !uploadError && (
                <p className="text-xs text-muted-foreground">{file.name}</p>
              )}
            </div>
          )}

          {step >= 5 && (
            <div>
              <h2 className="font-display text-lg font-semibold">Review your submission</h2>
              <dl className="mt-4 divide-y divide-border border-y border-border text-sm">
                {[
                  ["Team Name", form.team_name],
                  ["Participation Type", participationType],
                  ["Team Lead", form.team_lead_name],
                  ["Phone", form.team_lead_phone],
                  ["College", form.college_name],
                  ["Member 2", form.member2_name],
                  ["Member 3", form.member3_name],
                  ["Track", activeTracks.find((t) => t.id === form.track_id)?.name ?? "-"],
                  ["PPT", uploaded?.name ?? "Not uploaded"],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-6 py-3">
                    <dt className="font-mono text-[0.66rem] tracking-[0.18em] text-muted-foreground">
                      {String(k).toUpperCase()}
                    </dt>
                    <dd className="text-right">{v || "-"}</dd>
                  </div>
                ))}
              </dl>
              {step === LAST_STEP && (
                <div className="mt-6">
                  <Button
                    type="button"
                    size="lg"
                    disabled={submit.isPending}
                    onClick={() => submit.mutate()}
                  >
                    {submit.isPending && <Loader2 size={16} className="animate-spin" />}
                    CONFIRM & SUBMIT
                  </Button>
                  {submit.error && (
                    <p className="mt-3 text-sm text-destructive">
                      {(submit.error as Error).message}
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="mt-8 flex items-center justify-between gap-3 border-t border-border pt-6">
            <Button
              type="button"
              variant="ghost"
              disabled={step === 0}
              onClick={() => setStep((v) => Math.max(0, v - 1))}
            >
              <ArrowLeft size={15} /> BACK
            </Button>
            {step < LAST_STEP && (
              <Button
                type="button"
                disabled={step === 0 && participationOptions.length === 0}
                onClick={() => {
                  if (step === 0 && !participationType) {
                    setParticipationError("Please select IDEATION or PROTOTYPE to continue.");
                    return;
                  }
                  if (step === 4 && !uploaded) {
                    setUploadError("Please upload your project presentation.");
                    return;
                  }
                  if (validateStep()) setStep((v) => v + 1);
                }}
              >
                CONTINUE <ArrowRight size={15} />
              </Button>
            )}
          </div>
        </div>
      </div>
    </Shell>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <div className="grid-bg fixed inset-0 -z-10 opacity-40" aria-hidden="true" />
      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <Link
          to="/"
          className="font-mono text-[0.66rem] tracking-[0.2em] text-muted-foreground hover:text-foreground"
        >
          ← BACK TO SITE
        </Link>
        <div className="mt-10">{children}</div>
      </div>
    </div>
  );
}
