import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useCallback, useState } from "react";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { IdeationPrototype } from "@/components/site/IdeationPrototype";
import { Tracks } from "@/components/site/Tracks";
import { Schedule } from "@/components/site/Schedule";
import { Prizes } from "@/components/site/Prizes";
import { Winners } from "@/components/site/Winners";
import { Sponsors } from "@/components/site/Sponsors";
import { Faq } from "@/components/site/Faq";
import { TeamSelection } from "@/components/site/TeamSelection";
import { Footer } from "@/components/site/Footer";
import { LoadingScreen } from "@/components/site/LoadingScreen";
import {
  About,
  Certificates,
  FinalCta,
  Format,
  HowItWorks,
  Judging,
} from "@/components/site/Sections";
import {
  benefitsQuery,
  contentQuery,
  criteriaQuery,
  faqsQuery,
  prizesQuery,
  scheduleQuery,
  settingsQuery,
  sponsorTiersQuery,
  sponsorsQuery,
  tracksQuery,
  winnersQuery,
} from "@/lib/cms";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Innovators Fest 2026 | 35-Hour Hackathon in Hyderabad" },
      {
        name: "description",
        content:
          "Innovators Fest 2026 - a 35-hour national hackathon and startup innovation event at Ghulam Ahmed Hall, MJCET, Hyderabad on 13-14 October 2026. Build. Pitch. Launch.",
      },
      { property: "og:title", content: "Innovators Fest 2026 | 35-Hour Hackathon in Hyderabad" },
      {
        property: "og:description",
        content:
          "Build for 35 hours, pitch before judges on Day 2, and win prizes, certificates and startup support. Organized by Sultan Uloom Knowledge Hub.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const settings = useQuery(settingsQuery);
  const content = useQuery(contentQuery);
  const tracks = useQuery(tracksQuery);
  const schedule = useQuery(scheduleQuery);
  const criteria = useQuery(criteriaQuery);
  const prizes = useQuery(prizesQuery);
  const benefits = useQuery(benefitsQuery);
  const faqs = useQuery(faqsQuery);
  const sponsors = useQuery(sponsorsQuery);
  const tiers = useQuery(sponsorTiersQuery);
  const winners = useQuery(winnersQuery);

  const [loaded, setLoaded] = useState(false);
  const finishLoading = useCallback(() => setLoaded(true), []);

  const s = settings.data;
  const c = content.data ?? {};

  const loaderOn = s ? s.loading_enabled && !loaded : true;

  return (
    <>
      {loaderOn && (
        <LoadingScreen
          eventName={s?.event_name ?? "INNOVATORS FEST 2026"}
          loadingText={s?.loading_text ?? "LOADING..."}
          logoPath={s ? (s.loading_logo_url ?? s.organizer_logo_url) : undefined}
          onDone={finishLoading}
          hold={!s}
        />
      )}
      {s && (
        <>
      <Nav
        eventName={s.event_name}
        ctaLabel={s.registration_button_text}
        logoPath={s.organizer_logo_url}
      />
      <main>
        <Hero hero={c["hero"]} settings={s} />
        <About about={c["about"]} settings={s} />
        <IdeationPrototype block={c["ideation_prototype"]} />
        <Format format={c["format"]} />
        <Tracks tracks={tracks.data ?? []} />
        <HowItWorks block={c["how_it_works"]} />
        <Schedule items={schedule.data ?? []} />
        <Judging block={c["judging"]} criteria={criteria.data ?? []} />
        <Prizes block={c["prizes"]} prizes={prizes.data ?? []} benefits={benefits.data ?? []} />
        <Certificates block={c["certificates"]} />
        <Winners block={c["winners"]} winners={winners.data ?? []} />
        <Sponsors block={c["sponsors"]} sponsors={sponsors.data ?? []} tiers={tiers.data ?? []} />
        <TeamSelection />
        <Faq block={c["faq"]} faqs={faqs.data ?? []} />
        <FinalCta block={c["cta"]} buttonLabel={s.registration_button_text} />
      </main>
      <Footer settings={s} block={c["footer"]} />
        </>
      )}
    </>
  );
}
